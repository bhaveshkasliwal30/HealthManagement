
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.internal.OracleTypes;

public class HealthSupporterBO extends UserBO {

	String isPrimary;
	String authorizedOn;
	String authorizedTill;
	int healthSupporterId;
	String contact;

	public HealthSupporterBO() {

	}

	public HealthSupporterBO(int userId, String name, String dob, String gender, String address, String username,
			String password, String ssn, String isPrimary, String authorizedOn, String authorizedTill,
			int healthSupporterId, String contact) {

		super(userId, name, dob, gender, address, username, password, ssn);

		this.isPrimary = isPrimary;
		this.authorizedOn = authorizedOn;
		this.authorizedTill = authorizedTill;
		this.healthSupporterId = healthSupporterId;
		this.contact = contact;
	}

	// Description : Method to add / update the details of a health supporter
	// for a patient
	// returns : 0: Unable to perform the operation;
	// 1: Health Supporter tagged successfully;
	// 2: Health Supporter tagged as a Primary health supporter;
	// 3: Health Supporter details updated successfully;
	// 4: No other primary health supporter exists;
	// 5: Invalid health supporter id;
	public static String InsertUpdateHealthSupporter(String username, int healthSupporterId, int patientId,
			boolean isPrimaryHealthSupporter, String authorizedOn, String authorizedTill, String contact) {
		int result = 0;

		int userid = getUserIdFromUserName(username);
		int userIdPatient = PatientBO.getUserIdFromPatientId(patientId);

		if (userid > 0) {

			if (userid != userIdPatient) {

				ConnectionToOracle con = new ConnectionToOracle();

				try {
					Connection c1 = con.returnConnection();

					CallableStatement cStmt = c1
							.prepareCall("{call InsertUpdateHealthSupporter(?, ?, ?, ?, ?, ?, ?, ?)}");

					cStmt.setLong(1, userid);
					cStmt.setInt(2, healthSupporterId);
					cStmt.setInt(3, patientId);
					cStmt.setString(4, isPrimaryHealthSupporter ? "Y" : "N");
					cStmt.setString(5, contact);
					cStmt.setDate(6, java.sql.Date.valueOf(authorizedOn));
					cStmt.setDate(7, java.sql.Date.valueOf(authorizedTill));

					cStmt.registerOutParameter(8, OracleTypes.INTEGER);

					cStmt.executeUpdate();

					result = cStmt.getInt(8);

					cStmt.close();

					con.connectionClose();

				} catch (Exception ex) {
					System.out.println(ex.getMessage());

					if (con != null)
						con.connectionClose();
				} finally {
					if (con != null)
						con.connectionClose();
				}

				switch (result) {
				case 0:
					return "Unable to perform the operation";
				case 1:
					return "Health Supporter tagged successfully";
				case 2:
					return "Health Supporter tagged as a primary health supporter";
				case 3:
					return "Health Supporter details updated successfully";
				case 4:
					return "No other primary health supporter exists";
				case 5:
					return "Invalid health supporter id";
				case 6:
					return "User already tagged as a health supporter";
				case 7:
					return "Cannot add healthsupporter since already two health supporters exist";
				case 8:
					return "Health supporter tagged as a secondary health supporter";
				default:
					return "Internal error";
				}
			} else {
				return "A patient cannot be his/her own health supporter.";
			}

		} else {
			return "Invalid username";
		}
	}

	// Description : Method to delete a health supporter tagged to a patient
	// returns : 0: Unable to perform the operation;
	// 1: Health Supporter deleted successfully;
	// 2: Cannot delete since no other health supporter exists;
	// 3: Invalid healthsupporterId / patientId
	public static String DeleteHealthSupporter(int healthSupporterId, int patientId) {

		int result = 0;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			Connection c1 = con.returnConnection();

			CallableStatement cStmt = c1.prepareCall("{call DeleteHealthSupporter(?, ?, ?)}");

			cStmt.setInt(1, healthSupporterId);
			cStmt.setInt(2, patientId);

			cStmt.registerOutParameter(3, OracleTypes.INTEGER);

			cStmt.executeUpdate();

			result = cStmt.getInt(3);

			cStmt.close();

			con.connectionClose();

		} catch (Exception ex) {
			if (con != null)
				con.connectionClose();
		} finally {
			if (con != null)
				con.connectionClose();
		}

		switch (result) {
		case 0:
			return "Unable to perform the operation";
		case 1:
			return "Health Supporter deleted successfully";
		case 2:
			return "Cannot delete since no other health supporter exists";
		case 3:
			return "Invalid healthsupporterId / patientId";
		default:
			return "";
		}
	}

	// Description : Method to get list of patients tagged to a health supporter
	public static ArrayList<PatientBO> GetListOfPatientsForHealthSupporter(int healthSupporterId) {
		ArrayList<PatientBO> listPatients = new ArrayList<PatientBO>();

		ResultSet result = null;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			Connection c1 = con.returnConnection();

			CallableStatement cStmt = c1.prepareCall("{call getPatientListForHS(?, ?)}");

			cStmt.setInt(1, healthSupporterId);

			cStmt.registerOutParameter(2, OracleTypes.CURSOR);

			cStmt.executeUpdate();

			result = (ResultSet) cStmt.getObject(2);

			if (result != null) {
				while (result.next()) {
					listPatients.add(new PatientBO(result.getInt("USERID"), result.getString("NAME"),
							result.getString("DOB"), result.getString("GENDER"), result.getString("ADDRESS"), "", "",
							result.getString("SSN")));
				}
			}

			cStmt.close();

			con.connectionClose();

		} catch (Exception ex) {
			if (con != null)
				con.connectionClose();
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return listPatients;
	}

	// Description : Method to get list of health supporters tagged to a patient
	public static ArrayList<HealthSupporterBO> GetListOfHSForPatient(int patientId) {
		ArrayList<HealthSupporterBO> listHS = new ArrayList<HealthSupporterBO>();

		ResultSet result = null;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			Connection c1 = con.returnConnection();

			CallableStatement cStmt = c1.prepareCall("{call getHSListForPatient(?, ?)}");

			cStmt.setInt(1, patientId);

			cStmt.registerOutParameter(2, OracleTypes.CURSOR);

			cStmt.executeUpdate();

			result = (ResultSet) cStmt.getObject(2);

			if (result != null) {
				while (result.next()) {
					listHS.add(new HealthSupporterBO(result.getInt("userid"), result.getString("NAME"), ""/* DOB */,
							""/* result.getString("GENDER") */,
							""/* result.getString("ADDRESS") */, result.getString("username"), "",
							""/* result.getString("SSN") */, result.getString("IsPrimary"),
							result.getString("AuthorizedOn"), result.getString("AuthorizedTill"),
							result.getInt("HealthSupporterId"), result.getString("contact")));
				}
			}

			cStmt.close();

			con.connectionClose();

		} catch (Exception ex) {
			if (con != null)
				con.connectionClose();
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return listHS;
	}

	// Description : Method to add / update the details of a health supporter
	// for a patient
	// returns : 0: Unable to perform the operation;
	// 1: Health Supporter tagged successfully;
	// 2: Health Supporter tagged as a Primary health supporter;
	// 3: Health Supporter details updated successfully;
	// 4: No other primary health supporter exists;
	// 5: Invalid health supporter id;
	public static String InsertUpdateRecommendation(int healthRecommendationId, Integer healthObservationId,
			Integer diagnosisId, int patientId, int alertThreshold, int upperLimit, int lowerLimit, int frequency, int inactivityThershold, int consecutiveReadings) {
		int result = 0;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			Connection c1 = con.returnConnection();

			CallableStatement cStmt = c1.prepareCall("{call InsertUpdateHealthSupporter(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");

			cStmt.setLong(1, healthRecommendationId);
			cStmt.setLong(2, healthObservationId);
			cStmt.setLong(3, diagnosisId);
			cStmt.setLong(4, patientId);
			cStmt.setInt(5, alertThreshold);
			cStmt.setInt(6, upperLimit);
			cStmt.setInt(7, lowerLimit);
			cStmt.setInt(8, frequency);

			cStmt.setInt(9, inactivityThershold);
			cStmt.setInt(10, consecutiveReadings);
			
			cStmt.registerOutParameter(11, OracleTypes.INTEGER);

			cStmt.executeUpdate();

			result = cStmt.getInt(11);

			cStmt.close();

			con.connectionClose();

		} catch (Exception ex) {
			if (con != null)
				con.connectionClose();
		} finally {
			if (con != null)
				con.connectionClose();
		}

		switch (result) {
		case 0:
			return "Unable to perform the operation";
		case 1:
			return "Health recommendation added successfully";
		case 2:
			return "A default health recommendation already exists for the health observation";
		case 3:
			return "Health recommendation already exists for the patient";
		case 4:
			return "Health recommendation updated successfully";
		case 5:
			return "Health recommendation updated successfully";
		default:
			return "Internal error";
		}
	}

	/*
	 *  Description : Method to get the id of the health supporter against a user id
	 *  return -1 in case health supporter id not found 
	 */
	public static int getHealthSupporterIdForUserId(int userId) {
		
		int result = -1;

		ConnectionToOracle con = new ConnectionToOracle();

		try {

			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "SELECT HealthSupporterId FROM HEALTHSUPPORTER WHERE USERID=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, userId);

			ResultSet rs = pstmt.executeQuery();

			if (rs != null && rs.next())
				result = rs.getInt("HealthSupporterId");

			if (rs != null)
				rs.close();

			pstmt.close();

			con.connectionClose();

		} catch (SQLException e1) {
			return -1;
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;
	}
}