import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.internal.OracleTypes;

public class AlertsBO {

	public static Object[][] getAlerts(int patientId) throws SQLException {

		Object[][] s = null;
		System.out.println("getAlerts called");
		ConnectionToOracle con = new ConnectionToOracle();

		Connection c1 = con.returnConnection();

		PreparedStatement pstmt = null;

		ResultSet rs = null;

		try {

			String query = "select count(*) from alerts a inner join ALERTTYPE alt on a.ALERTTYPEID = alt.ALERTTYPEID where CLEAREDON is null and PATIENTID = ?";

			pstmt = c1.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE);

			pstmt.setInt(1, patientId);

			rs = pstmt.executeQuery();

			rs.next();

			int count = 0;

			count = rs.getInt(1);

			String queryq = "select a.AlertId, a.Timestamp, a.Description, a.ViewedOn, alt.DESCRIPTION as ALERT_DESC, u.name as ViewedByName from alerts a inner join ALERTTYPE alt on a.ALERTTYPEID = alt.ALERTTYPEID left join Users u ON(u.Userid = ViewedBy) where CLEAREDON is null and PATIENTID = ?";

			pstmt = c1.prepareStatement(queryq, ResultSet.TYPE_SCROLL_INSENSITIVE);

			pstmt.setInt(1, patientId);

			rs = pstmt.executeQuery();

			s = new Object[count][6];

			count = 0;

			while (rs.next()) {

				Object[] row = new Object[6];

				row[0] = rs.getInt("ALERTID");

				row[1] = rs.getTimestamp("TIMESTAMP");

				row[2] = rs.getString("ALERT_DESC");

				row[3] = rs.getString("DESCRIPTION");
				
				row[4] = rs.getString("ViewedOn");
				
				row[5] = rs.getString("ViewedByName");

				s[count] = row;
				
				count = count + 1;

			}

			rs.close();

			pstmt.close();

			c1.close();

			con.close();

		} catch (Exception E) {

			rs.close();

			pstmt.close();

			c1.close();

			con.close();

			System.out.println("error while fetching alerts, error: " + E.getMessage());

		}

		return s;

	}

	// Method to set the view flag for the alert
	public static boolean UpdateViewedFlagForAlerts(int alertId, int userId) {

		boolean result = false;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "UPDATE ALERTS SET ViewedOn = current_timestamp, ViewedBy = ? WHERE ALERTID = ?";
			pstmt = c1.prepareStatement(query);

			pstmt.setInt(1, userId);
			pstmt.setInt(2, alertId);

			int rowsAffected = pstmt.executeUpdate();

			result = rowsAffected > 0;

			pstmt.close();

			con.connectionClose();
			
		} catch (SQLException e1) {
			System.out.println(e1.getMessage());
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;
	}

	// Method to set the clear flag for the alert
	public static boolean UpdateClearFlagForAlerts(int alertId, int userId) {

		boolean result = false;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "UPDATE ALERTS SET ClearedOn = current_timestamp, ClearedBy = ? WHERE ALERTID = ? AND VIEWEDON IS NOT NULL";
			pstmt = c1.prepareStatement(query);

			pstmt.setInt(1, userId);
			pstmt.setInt(2, alertId);

			int rowsAffected = pstmt.executeUpdate();

			result = rowsAffected > 0;

			pstmt.close();

			con.connectionClose();
			
		} catch (SQLException e1) {
			System.out.println(e1.getMessage());
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;
	}
	
	
	// Method to generate the Over-the-limit alerts for a patient
	public static boolean GenerateOverTheLimitAlerts(int patientId) {
		int result = 0;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			Connection c1 = con.returnConnection();

			CallableStatement cStmt = c1.prepareCall("{call GenerateOverTheLimitAlerts(?, ?)}");

			cStmt.setLong(1, patientId);

			cStmt.registerOutParameter(2, OracleTypes.INTEGER);

			cStmt.executeUpdate();

			result = cStmt.getInt(2);

			cStmt.close();

			con.connectionClose();

		} catch (Exception ex) {
			if (con != null)
				con.connectionClose();
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return (result == 1);
	}
}
