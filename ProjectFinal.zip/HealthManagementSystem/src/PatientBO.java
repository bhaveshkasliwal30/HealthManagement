import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientBO extends UserBO {

	public PatientBO(int userId, String name, String dob, String gender, String address, String username,
			String password, String ssn) {
		super(userId, name, dob, gender, address, username, password, ssn);
	}

	// Description : Methods to get the userID from a username
	public static int getUserIdFromPatientId(int patientid) {
		int result = 0;

		ConnectionToOracle con = new ConnectionToOracle();

		try {

			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "select userid from patients where patientid=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientid);

			ResultSet rs = pstmt.executeQuery();

			if (rs != null && rs.next())
				result = rs.getInt("userid");

			if (rs != null)
				rs.close();

			pstmt.close();

			con.connectionClose();

		} catch (SQLException e1) {
			return -1;
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;
	}
}
