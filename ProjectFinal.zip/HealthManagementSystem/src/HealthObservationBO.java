import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class HealthObservationBO {
	public int healthObservationId;
	public String healthObservationName;
	public boolean isOrdinal;
	public int ordinalValue;
	public String ordinalName;

	public HealthObservationBO() {

	}

	public HealthObservationBO(int healthObservationId, String healthObservationName, boolean isOrdinal,
			int ordinalValue, String ordinalName) {
		this.healthObservationId = healthObservationId;
		this.healthObservationName = healthObservationName;
		this.isOrdinal = isOrdinal;
		this.ordinalValue = ordinalValue;
		this.ordinalName = ordinalName;
	}

	public static ArrayList<HealthObservationBO> getNonOrdinalHealthRecommendations() {
		ArrayList<HealthObservationBO> result = new ArrayList<HealthObservationBO>();

		ConnectionToOracle con = new ConnectionToOracle();

		try {

			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "SELECT ob.HEALTHOBSERVATIONID, ob.HEALTHOBSERVATIONNAME FROM HEALTHOBSERVATIONS ob WHERE ob.ISORDINAL='N'";
			pstmt = c1.prepareStatement(query);
			
			ResultSet rs = pstmt.executeQuery();

			while (rs != null && rs.next())
				result.add(new HealthObservationBO(rs.getInt("HEALTHOBSERVATIONID"), rs.getString("HEALTHOBSERVATIONNAME"), false, 0, ""));

			if (rs != null)
				rs.close();

			pstmt.close();

			con.connectionClose();

		} catch (SQLException e1) {
			return null;
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;		
	}
	
	public static ArrayList<HealthObservationBO> getOrdinalHealthRecommendations() {
		ArrayList<HealthObservationBO> result = new ArrayList<HealthObservationBO>();
		
		ConnectionToOracle con = new ConnectionToOracle();

		try {
			
			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "SELECT ob.HEALTHOBSERVATIONID, ob.HEALTHOBSERVATIONNAME, ord.ORDINALVALUE, ord.DESCRIPTION FROM HEALTHOBSERVATIONS ob INNER JOIN ORDINAL ord ON (ob.HEALTHOBSERVATIONID = ord.HEALTHOBSERVATIONID) WHERE ob.ISORDINAL = 'Y'";
			pstmt = c1.prepareStatement(query);
			
			ResultSet rs = pstmt.executeQuery();

			while (rs != null && rs.next())
				result.add(new HealthObservationBO(
						rs.getInt("HEALTHOBSERVATIONID")
						,rs.getString("HEALTHOBSERVATIONNAME")
						,true, rs.getInt("ORDINALVALUE"), rs.getString("DESCRIPTION")));;

			if (rs != null)
				rs.close();

			pstmt.close();

			con.connectionClose();

		} catch (SQLException e1) {
			return null;
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;		
	}
}
