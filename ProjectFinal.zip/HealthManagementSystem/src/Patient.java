import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JTabbedPane;
import javax.swing.JDesktopPane;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.awt.event.ActionEvent;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import org.omg.CORBA.PUBLIC_MEMBER;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class Patient {

	//Patient window;
	JFrame frmPatient;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPasswordField passwordField;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	int userId,patientId, hsid;
	boolean is_hs;
	int cur_user;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private int phid,shid;
	private String phusername,shusername,phauthdate,phcontact,shauthdate,shcontact;
	private JTextField textField_16;
	private JTextField txtReadingValue;
	private JTextField txtYyyymmddHhmmss;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table;
	Object[][] data;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) throws SQLException {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Patient window = new Patient(6);
//					window.frmPatient.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	
	
	
	public Patient(int id, int hsid, boolean is_hs) throws SQLException{
		userId=id;
		this.hsid = hsid;
		this.is_hs = is_hs;
		patientId=Integer.parseInt(DBHandling.getUserProfile(id).get("patientId"));
		System.out.println(patientId);
		initialize();
	}
	public Patient(int id) throws SQLException{
		userId=id;
		this.hsid = 0;
		this.is_hs = false;
		patientId=Integer.parseInt(DBHandling.getUserProfile(id).get("patientId"));
		System.out.println(patientId);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() throws SQLException {
		cur_user = userId;
		if(is_hs){
			cur_user = hsid;
		}
		frmPatient = new JFrame();
		frmPatient.getContentPane().setBackground(Color.BLACK);
		frmPatient.setTitle("Patient");
		frmPatient.setBounds(50, 50, 1150, 800);
		frmPatient.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JLabel lblPersonalHealthMangement = new JLabel("Personal Health Mangement");
		lblPersonalHealthMangement.setHorizontalAlignment(SwingConstants.CENTER);
		lblPersonalHealthMangement.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPersonalHealthMangement.setBackground(Color.BLACK);
		lblPersonalHealthMangement.setForeground(Color.RED);
		frmPatient.getContentPane().add(lblPersonalHealthMangement, BorderLayout.NORTH);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.BLACK);
		frmPatient.getContentPane().add(desktopPane, BorderLayout.CENTER);
		desktopPane.setLayout(new MigLayout("", "[][][][][][grow][][]", "[][][][][][][][][][]"));
		
		JLabel lblUid = new JLabel("Username");
		lblUid.setForeground(Color.WHITE);
		lblUid.setBackground(Color.BLACK);
		desktopPane.add(lblUid, "cell 3 0");
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBackground(Color.BLACK);
		desktopPane.add(lblNewLabel, "cell 5 0");
		
		JLabel lblNewLabel_7 = new JLabel("    ");
		lblNewLabel_7.setBackground(Color.BLACK);
		desktopPane.add(lblNewLabel_7, "cell 6 0");
		
		JLabel lblNewLabel_6 = new JLabel("     ");
		lblNewLabel_6.setBackground(Color.BLACK);
		desktopPane.add(lblNewLabel_6, "cell 7 0");
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setBackground(Color.BLACK);
		desktopPane.add(lblPassword, "cell 3 1");
		
		passwordField = new JPasswordField();
		desktopPane.add(passwordField, "cell 5 1,growx");
		
		JLabel lblDob = new JLabel("DOB");
		lblDob.setBackground(Color.BLACK);
		lblDob.setForeground(Color.WHITE);
		desktopPane.add(lblDob, "cell 3 2");
		
		textField = new JTextField();
		desktopPane.add(textField, "cell 5 2,growx");
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setForeground(Color.WHITE);
		desktopPane.add(lblNewLabel_1, "cell 3 3");
		
		textField_1 = new JTextField();
		desktopPane.add(textField_1, "cell 5 3,growx");
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Address");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBackground(Color.BLACK);
		desktopPane.add(lblNewLabel_2, "cell 3 4");
		
		textField_2 = new JTextField();
		desktopPane.add(textField_2, "cell 5 4,growx");
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Gender");
		lblNewLabel_3.setBackground(Color.BLACK);
		lblNewLabel_3.setForeground(Color.WHITE);
		desktopPane.add(lblNewLabel_3, "cell 3 5");
		
		JRadioButton rdbtnMale = new JRadioButton("Male");
		buttonGroup.add(rdbtnMale);
		rdbtnMale.setForeground(Color.WHITE);
		rdbtnMale.setBackground(Color.BLACK);
		desktopPane.add(rdbtnMale, "flowx,cell 5 5");
		
		JLabel lblCategory = new JLabel("Category");
		lblCategory.setBackground(Color.BLACK);
		lblCategory.setForeground(Color.WHITE);
		desktopPane.add(lblCategory, "cell 3 6");
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setBackground(Color.BLACK);
		desktopPane.add(lblNewLabel_5, "cell 5 6");
		
		JLabel lblNewLabel_4 = new JLabel("      ");
		lblNewLabel_4.setBackground(Color.BLACK);
		desktopPane.add(lblNewLabel_4, "flowx,cell 3 7");
		
		JRadioButton rdbtnFemale = new JRadioButton("Female");
		buttonGroup.add(rdbtnFemale);
		rdbtnFemale.setForeground(Color.WHITE);
		rdbtnFemale.setBackground(Color.BLACK);
		desktopPane.add(rdbtnFemale, "cell 5 5");
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(check(String.valueOf(passwordField.getPassword()),textField.getText(),textField_1.getText(),textField_2.getText(),getSelectedButton())==0){
					JOptionPane.showMessageDialog(frmPatient,"Wrong or Unfilled Entry");
				}
				else{
					try {
						if(DBHandling.insertUpdatePatient(userId,textField_1.getText(),textField.getText(),getSelectedButton(),textField_2.getText(),lblNewLabel.getText(),String.valueOf(passwordField.getPassword()),textField_11.getText()))
						{
							JOptionPane.showMessageDialog(frmPatient,"Update Successful");
						}
						else
						{
							JOptionPane.showMessageDialog(frmPatient,"Cannot Update!");
						}
					} catch (HeadlessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//	insertData(textField.getText(),textField_1.getText(),textField_2.getText(),textField_4.getText(),txtMmddyy.getText(),textField_5.getText(),getSelectedButton());
				}
			}
		});
		
		textField_11 = new JTextField();
		desktopPane.add(textField_11, "cell 5 7,growx");
		textField_11.setColumns(10);
		if(!is_hs){
		btnUpdate.setForeground(Color.BLUE);
		desktopPane.add(btnUpdate, "cell 4 8");
		}
		JLabel lblSsn = new JLabel("SSN");
		lblSsn.setForeground(Color.WHITE);
		lblSsn.setBackground(Color.BLACK);
		desktopPane.add(lblSsn, "cell 3 7");
		
		JDesktopPane desktopPane_1 = new JDesktopPane();
		desktopPane_1.setBackground(Color.BLACK);
//		frmPatient.getContentPane().add(desktopPane_1, BorderLayout.CENTER);
		desktopPane_1.setLayout(new MigLayout("", "[][grow][grow][][][][grow][][grow]", "[][][][grow][][]"));
		
		JComboBox<String> comboBox = new JComboBox<String>();
		desktopPane_1.add(comboBox, "cell 1 1 2 1,growx");
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selected_disease=comboBox.getSelectedItem().toString();
				if (!selected_disease.equals(null))
				{
					HashMap<Integer, HashMap<String, Boolean>> map = new HashMap<Integer, HashMap<String, Boolean>>();
					try {
						map = DBHandling.getUserDiseases(patientId);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					for(int diagnosisId : map.keySet()){
						HashMap<String, Boolean> inner_map = map.get(diagnosisId);
						for(String disease : inner_map.keySet()){
							boolean val = inner_map.get(disease);
							if(!val && disease.equals(selected_disease))
							{
								try {
									if(!DBHandling.addDisease(patientId,diagnosisId,textField_16.getText()))
									{
										JOptionPane.showMessageDialog(frmPatient,"Please add atleast One Health Supporter !");
									}
									else
									{
										textField_16.setText(null);
										desktopPane_1.setVisible(false);
										break;}
								} catch (HeadlessException | SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
				}
			}
		}}});
		btnAdd.setForeground(Color.RED);
		desktopPane_1.add(btnAdd, "cell 4 1");
		
		JComboBox<String> comboBox_1 = new JComboBox<String>();
		desktopPane_1.add(comboBox_1, "cell 6 1 2 1,growx");
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selected_disease=comboBox_1.getSelectedItem().toString();
				if (!selected_disease.equals(null))
				{
					HashMap<Integer, HashMap<String, Boolean>> map = new HashMap<Integer, HashMap<String,Boolean>>();
					try {
						map = DBHandling.getUserDiseases(patientId);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					for(int diagnosisId : map.keySet()){
						HashMap<String, Boolean> inner_map = map.get(diagnosisId);
						for(String disease : inner_map.keySet()){
							boolean val = inner_map.get(disease);
							if(val && disease.equals(selected_disease))
							{
								try {
									if(!DBHandling.removeDisease(patientId,diagnosisId))
									{
										JOptionPane.showMessageDialog(frmPatient,"Unable to remove");
									}
									else
									{
										desktopPane_1.setVisible(false);
										break;
									}
								} catch (HeadlessException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
				}
			}
		}	
			}
		});
		btnRemove.setForeground(Color.BLUE);
		desktopPane_1.add(btnRemove, "cell 8 1");
		
		JLabel lblNewLabel_14 = new JLabel("Diagnosis Start Date: ");
		lblNewLabel_14.setForeground(Color.RED);
		desktopPane_1.add(lblNewLabel_14, "cell 1 2,alignx trailing");
		
		textField_16 = new JTextField();
		desktopPane_1.add(textField_16, "cell 2 2,growx");
		textField_16.setColumns(10);
		
		JDesktopPane desktopPane_2 = new JDesktopPane();
		desktopPane_2.setBackground(Color.BLACK);
//		frmPatient.getContentPane().add(desktopPane_2, BorderLayout.CENTER);
		
		JLabel lblEnterReading = new JLabel("Enter Reading");
		lblEnterReading.setForeground(Color.GREEN);
		
		JLabel lblReadingVaue = new JLabel("Reading Vaue");
		lblReadingVaue.setForeground(Color.GREEN);
		
		JLabel lblObservationTime = new JLabel("Observation Time");
		lblObservationTime.setForeground(Color.GREEN);
		JComboBox<String> comboBox_2 = new JComboBox<String>();
		txtReadingValue = new JTextField();
		txtReadingValue.setText("reading value");
		txtReadingValue.setColumns(10);
		
		JButton btnAdd_1 = new JButton("Add");
		
		txtYyyymmddHhmmss = new JTextField();
		txtYyyymmddHhmmss.setText("yyyy-mm-dd hh:mm:ss");
		txtYyyymmddHhmmss.setColumns(10);
		
		btnAdd_1.setForeground(Color.BLUE);
		
		btnAdd_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				HashMap<Integer, HashMap<String, String>> health_obs = new HashMap<Integer, HashMap<String,String>>();
				try {
					health_obs = DBHandling.getHealthObservations(patientId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//comboBox_2.getSelectedItem()
				int hoid=0;
				for(int healthobservationid : health_obs.keySet()){
					HashMap<String, String> inner_map = health_obs.get(healthobservationid);
					if(comboBox_2.getSelectedItem().equals(inner_map.get("HealthObservationName")))
					{
						hoid=healthobservationid;
						break;
					}
											
				}
				System.out.println(Integer.parseInt(txtReadingValue.getText()));
				if(!txtReadingValue.getText().isEmpty()){
					
				try {
					DBHandling.addReading(patientId, hoid, Integer.parseInt(txtReadingValue.getText()), txtYyyymmddHhmmss.getText(), null);
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
//				desktopPane_2.setVisible(false);
				
			}
				else
				{
					JOptionPane.showMessageDialog(frmPatient,"Please Enter Reading Value");
				}
				try {
					Object[][] data5 = DBHandling.getReadings(patientId);
					String[] columnNames5 = {"Upload Time", "Reading Value", "Observation Time", "Observation", "Metric"};
					DefaultTableModel model5 = new DefaultTableModel(data5, columnNames5);
					table.setModel(model5);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				try {
					HashMap<Integer, HashMap<String, String>> hr4 = DBHandling.getHealthIndicators(patientId);
					String[] columnNames4 = {"HealthObservationName", "Metric", "Threshold", "UpperLimit", "LowerLimit", "Frequency"};
			        Object[][] data4 = new Object[hr4.size()][5];
			        Integer count4 = 0;
					for(int hrId : hr4.keySet()){
						HashMap<String, String> inner_map = hr4.get(hrId);
						Object[] temp_data = {
								inner_map.get("HealthObservationName"),
								inner_map.get("metric"),
								inner_map.get("Threshold"),
								inner_map.get("UpperLimit"),
								inner_map.get("LowerLimit"),
								inner_map.get("Frequency")		
						};
						data4[count4] = temp_data;
						count4 = count4 + 1;
					}
				
			        DefaultTableModel model4 = new DefaultTableModel(data4, columnNames4);
					
					table_3.setModel(model4);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		

		btnAdd_1.setForeground(Color.BLUE);
		
		JPanel panel_1 = new JPanel();
		
		JLabel lblRecommendations = new JLabel("Recommendations:");
		lblRecommendations.setForeground(Color.GREEN);
		
		JLabel lblReadings = new JLabel("Readings:");
		lblReadings.setForeground(Color.GREEN);
		
		JPanel panel_2 = new JPanel();
		GroupLayout gl_desktopPane_2 = new GroupLayout(desktopPane_2);
		gl_desktopPane_2.setHorizontalGroup(
			gl_desktopPane_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_desktopPane_2.createSequentialGroup()
					.addGap(45)
					.addGroup(gl_desktopPane_2.createParallelGroup(Alignment.LEADING)
						.addComponent(lblRecommendations)
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 1021, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_desktopPane_2.createSequentialGroup()
							.addGap(6)
							.addGroup(gl_desktopPane_2.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_desktopPane_2.createSequentialGroup()
									.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(lblObservationTime, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(txtYyyymmddHhmmss, GroupLayout.PREFERRED_SIZE, 198, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(lblEnterReading, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(txtReadingValue, GroupLayout.PREFERRED_SIZE, 198, GroupLayout.PREFERRED_SIZE)
									.addGap(91)
									.addComponent(btnAdd_1))
								.addComponent(lblReadings)
								.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
					.addContainerGap(68, Short.MAX_VALUE))
		);
		gl_desktopPane_2.setVerticalGroup(
			gl_desktopPane_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_desktopPane_2.createSequentialGroup()
					.addGap(16)
					.addGroup(gl_desktopPane_2.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_desktopPane_2.createSequentialGroup()
							.addGap(1)
							.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_desktopPane_2.createSequentialGroup()
							.addGap(5)
							.addComponent(lblObservationTime))
						.addComponent(txtYyyymmddHhmmss, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_desktopPane_2.createSequentialGroup()
							.addGap(5)
							.addComponent(lblEnterReading))
						.addComponent(txtReadingValue, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAdd_1))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblReadings)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE)
					.addGap(50)
					.addComponent(lblRecommendations)
					.addGap(18)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 221, GroupLayout.PREFERRED_SIZE)
					.addGap(35))
		);
		
		String[] columnNames5 = {"Upload Time", "Reading Value", "Observation Time", "Observation", "Metric"};
        Object[][] data5 = DBHandling.getReadings(patientId);
        DefaultTableModel model5 = new DefaultTableModel(data5, columnNames5);
		table = new JTable(model5);
		
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setBackground(Color.WHITE);
		table.setForeground(Color.RED);
        JTableHeader header5 = table.getTableHeader();
        panel_2.setLayout(new BorderLayout());
		panel_2.add(header5, BorderLayout.NORTH);
		panel_2.add(table);
		JScrollPane js=new JScrollPane(table);
        js.setVisible(true);
        panel_2.add(js);
		
		/////////////////////////////////////////
		HashMap<Integer, HashMap<String, String>> hr4 = DBHandling.getHealthIndicators(patientId);
		String[] columnNames4 = {"HealthObservationName", "Metric", "Threshold", "UpperLimit", "LowerLimit", "Frequency"};
        Object[][] data4 = new Object[hr4.size()][5];
        Integer count4 = 0;
		for(int hrId : hr4.keySet()){
			HashMap<String, String> inner_map = hr4.get(hrId);
			Object[] temp_data = {
					inner_map.get("HealthObservationName"),
					inner_map.get("metric"),
					inner_map.get("Threshold"),
					inner_map.get("UpperLimit"),
					inner_map.get("LowerLimit"),
					inner_map.get("Frequency")		
			};
			data4[count4] = temp_data;
			count4 = count4 + 1;
		}
	
        DefaultTableModel model4 = new DefaultTableModel(data4, columnNames4);
		
		table_3 = new JTable(model4);
		
		table_3.setColumnSelectionAllowed(true);
		table_3.setCellSelectionEnabled(true);
		table_3.setBackground(Color.WHITE);
		table_3.setForeground(Color.RED);
        JTableHeader header3 = table_3.getTableHeader();
		panel_1.setLayout(new BorderLayout());
		panel_1.add(header3, BorderLayout.NORTH);
		
		panel_1.add(table_3);
		JScrollPane js_3=new JScrollPane(table_3);
        js_3.setVisible(true);
        panel_1.add(js_3);
		desktopPane_2.setLayout(gl_desktopPane_2);
		
		JDesktopPane desktopPane_3 = new JDesktopPane();
		desktopPane_3.setBackground(Color.BLACK);
//		frmPatient.getContentPane().add(desktopPane_3, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		panel.setBounds(38, 128, 1078, 370);
		desktopPane_3.add(panel);
		
		
//		TABLE DATA
		HashMap<Integer, HashMap<String, String>> hr = DBHandling.getHealthIndicators(patientId);
		
		String[] columnNames = {"AlertId", "Time of Alert", "Alert Type", "Message", "Viewed On", "Viewed By Name"};
        data = AlertsBO.getAlerts(patientId);
        
        DefaultTableModel model2 = new DefaultTableModel(data, columnNames);
		
		table_2 = new JTable(model2);
        table_2.setColumnSelectionAllowed(true);
        table_2.setCellSelectionEnabled(true);
        table_2.setBackground(Color.WHITE);
        table_2.setForeground(Color.RED);
        JTableHeader header2 = table_2.getTableHeader();
		panel.setLayout(new BorderLayout());
		panel.add(header2, BorderLayout.NORTH);
		panel.add(table_2);
		JScrollPane js_2=new JScrollPane(table_2);
        js_2.setVisible(true);
        panel.add(js_2);
		JLabel lblAlertId = new JLabel("Alert Id: ");
		lblAlertId.setForeground(Color.GREEN);
		lblAlertId.setBounds(38, 18, 61, 16);
		desktopPane_3.add(lblAlertId);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(109, 14, 84, 27);
		
		for(Object[] dummy_data : data){
        	comboBox_3.addItem(dummy_data[0]);
        }
		
		desktopPane_3.add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(109, 55, 84, 27);
		for(Object[] dummy_data : data){
			if(is_hs){
				comboBox_4.addItem(dummy_data[0]);
			}
        	else {
				if(dummy_data[2].equals("Outside-the-limit alert")){
					comboBox_4.addItem(dummy_data[0]);
				}
			}
        }
		desktopPane_3.add(comboBox_4);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean res = AlertsBO.UpdateClearFlagForAlerts(Integer.parseInt(comboBox_3.getSelectedItem().toString()), cur_user);
				if(!res){
					JOptionPane.showMessageDialog(frmPatient,"Error clearing alert, please try again");
				}
				

				
				try {
					String[] columnNames = {"AlertId", "Time of Alert", "Alert Type", "Message", "Viewed On", "Viewed By Name"};
			        data = AlertsBO.getAlerts(patientId);
			        
			        DefaultTableModel model2 = new DefaultTableModel(data, columnNames);
					
					table_2.setModel(model2);
		        	comboBox_3.removeAllItems();;
					for(Object[] dummy_data : data){
			        	comboBox_3.addItem(dummy_data[0]);
			        }
					comboBox_4.removeAllItems();
					for(Object[] dummy_data : data){
						if(is_hs){
							comboBox_4.addItem(dummy_data[0]);
						}
			        	else {
							if(dummy_data[2].equals("Outside-the-limit alert")){
								comboBox_4.addItem(dummy_data[0]);
							}
						}
			        }
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(frmPatient,"Ooops!!");
				}
			}
		});
		btnClear.setBounds(205, 54, 117, 29);
		desktopPane_3.add(btnClear);
		
		JButton btnMarkAsViewed = new JButton("Mark as Viewed");
		btnMarkAsViewed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				boolean res = AlertsBO.UpdateViewedFlagForAlerts(Integer.parseInt(comboBox_3.getSelectedItem().toString()), cur_user);
				if(!res){
					JOptionPane.showMessageDialog(frmPatient,"Error updating alert, please try again");
				}
				
				
				
				try {
					String[] columnNames = {"AlertId", "Time of Alert", "Alert Type", "Message", "Viewed On", "Viewed By Name"};
			        data = AlertsBO.getAlerts(patientId);
			        
			        DefaultTableModel model2 = new DefaultTableModel(data, columnNames);
					
					table_2.setModel(model2);
					comboBox_3.removeAllItems();
					for(Object[] dummy_data : data){
			        	comboBox_3.addItem(dummy_data[0]);
			        }
					comboBox_4.removeAllItems();
					for(Object[] dummy_data : data){
						if(is_hs){
							comboBox_4.addItem(dummy_data[0]);
						}
			        	else {
							if(dummy_data[2].equals("Outside-the-limit alert")){
								comboBox_4.addItem(dummy_data[0]);
							}
						}
			        }
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
//				data = AlertsBO.getAlerts(patientId);
			}
		});
		btnMarkAsViewed.setBounds(205, 13, 150, 29);
		desktopPane_3.add(btnMarkAsViewed);
		
		JLabel label_12 = new JLabel("Alert Id: ");
		label_12.setForeground(Color.GREEN);
		label_12.setBounds(38, 59, 61, 16);
		desktopPane_3.add(label_12);
		
		
		
		JDesktopPane desktopPane_4 = new JDesktopPane();
		desktopPane_4.setBackground(Color.BLACK);
//		frmPatient.getContentPane().add(desktopPane_4, BorderLayout.CENTER);
		desktopPane_4.setLayout(new MigLayout("", "[][][][grow][][]", "[][][][][][][][][][][]"));
		
		JLabel lblPrimary = new JLabel("Primary Supporter");
		lblPrimary.setForeground(Color.WHITE);
		lblPrimary.setBackground(Color.BLACK);
		desktopPane_4.add(lblPrimary, "cell 0 0");
		
		JLabel lblNewLabel_10 = new JLabel("");
		desktopPane_4.add(lblNewLabel_10, "cell 4 0");
		
		JLabel lblNewLabel_9 = new JLabel("");
		desktopPane_4.add(lblNewLabel_9, "cell 5 0");
		
		JLabel label = new JLabel("Username");
		label.setForeground(Color.WHITE);
		desktopPane_4.add(label, "cell 1 1");
		
		textField_3 = new JTextField();
		desktopPane_4.add(textField_3, "flowx,cell 3 1,growx");
		textField_3.setColumns(10);
		
		JLabel lblName = new JLabel("Name");
		lblName.setForeground(Color.WHITE);
		lblName.setBackground(Color.BLACK);
		desktopPane_4.add(lblName, "cell 1 2");
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setBackground(Color.BLACK);
		desktopPane_4.add(lblNewLabel_8, "cell 3 2");
		
		JLabel lblAuthorizedFrom = new JLabel("Authorized From");
		lblAuthorizedFrom.setBackground(Color.BLACK);
		lblAuthorizedFrom.setForeground(Color.WHITE);
		desktopPane_4.add(lblAuthorizedFrom, "cell 1 3");
		
		textField_12 = new JTextField();
		textField_12.setToolTipText("yyyy-mm-dd");
		desktopPane_4.add(textField_12, "cell 3 3,growx");
		textField_12.setColumns(10);
		
		JLabel lblAuthorizedTill = new JLabel("Contact No.");
		lblAuthorizedTill.setBackground(Color.BLACK);
		lblAuthorizedTill.setForeground(Color.WHITE);
		desktopPane_4.add(lblAuthorizedTill, "cell 1 4");
		
		textField_13 = new JTextField();
		textField_13.setToolTipText("yyyy-mm-dd");
		desktopPane_4.add(textField_13, "cell 3 4,growx");
		textField_13.setColumns(10);
		
		JLabel lblSecondarySupporter = new JLabel("Secondary Supporter");
		lblSecondarySupporter.setForeground(Color.WHITE);
		lblSecondarySupporter.setBackground(Color.BLACK);
		desktopPane_4.add(lblSecondarySupporter, "cell 0 5");
		
		JLabel label_2 = new JLabel("Username");
		label_2.setForeground(Color.WHITE);
		desktopPane_4.add(label_2, "cell 1 6");
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		desktopPane_4.add(textField_4, "cell 3 6,growx");
		
		JLabel label_3 = new JLabel("Name");
		label_3.setForeground(Color.WHITE);
		label_3.setBackground(Color.BLACK);
		desktopPane_4.add(label_3, "cell 1 7");
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setBackground(Color.BLACK);
		lblNewLabel_13.setForeground(Color.WHITE);
		desktopPane_4.add(lblNewLabel_13, "cell 3 7");
		
		JLabel label_4 = new JLabel("Authorized From");
		label_4.setForeground(Color.WHITE);
		label_4.setBackground(Color.BLACK);
		desktopPane_4.add(label_4, "cell 1 8");
		
		textField_14 = new JTextField();
		textField_14.setToolTipText("yyyy-mm-dd");
		textField_14.setColumns(10);
		desktopPane_4.add(textField_14, "cell 3 8,growx");
		
		JLabel label_11 = new JLabel("Contact No.");
		label_11.setForeground(Color.WHITE);
		label_11.setBackground(Color.BLACK);
		desktopPane_4.add(label_11, "cell 1 9");
		
		textField_15 = new JTextField();
		textField_15.setToolTipText("yyyy-mm-dd");
		textField_15.setColumns(10);
		desktopPane_4.add(textField_15, "cell 3 9,growx");
		
		JButton btnUpdate_2 = new JButton("Update");
		btnUpdate_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String display="";
			/*	if(check_supporter(textField_3.getText(),textField_12.getText(),textField_13.getText(),textField_4.getText(),textField_14.getText(),textField_15.getText()))
				{
					System.out.println("vdfbf");
					JOptionPane.showMessageDialog(frmPatient,"Please fill all details !");
				}
				else*/
				{
					System.out.println(phid);
					if(phid==0)
					{
						//System.out.println(textField_3.getText()+ " "+0+" "+patientId+" "+textField_12.getText()+" "+textField_13.getText());
						//HealthSupporterBO.InsertUpdateHealthSupporter("p3", 0, 6, true, "2016-10-01", "2099-12-12", "4546565");
						//HealthSupporterBO.InsertUpdateHealthSupporter("p3",0,6,true,"21-10-2016","12-12-2099","546356");
						display=HealthSupporterBO.InsertUpdateHealthSupporter(textField_3.getText(),0,patientId,true,textField_12.getText(),"2099-12-12",textField_13.getText());
						System.out.println("gjg"+display);
						
						if (display.equals("Health Supporter details updated successfully")||display.equals("Health Supporter tagged as a Primary health supporter")||display.equals("Health Supporter tagged successfully"))
						{
							if(!textField_4.getText().isEmpty()&&!textField_14.getText().isEmpty()&&!textField_15.getText().isEmpty()&&shid==0)
							{
								display=HealthSupporterBO.InsertUpdateHealthSupporter(textField_4.getText(),0,patientId,false,textField_12.getText(),"2099-12-12",textField_13.getText());
							}
							if (!(display.equals("Health Supporter details updated successfully")||display.equals("Health Supporter tagged as a Primary health supporter")||display.equals("Health Supporter tagged successfully")))
								JOptionPane.showMessageDialog(frmPatient,"Secondary Failed a");
						}
						else
							JOptionPane.showMessageDialog(frmPatient,"Primary and/or Secondary Failed");
					}
					else if(phid!=0 &&textField_3.getText().isEmpty()&&shid!=0 &&textField_4.getText().isEmpty())
					{
						display=HealthSupporterBO.DeleteHealthSupporter(phid, patientId);
						display=HealthSupporterBO.DeleteHealthSupporter(shid, patientId);
						desktopPane_4.setVisible(false);
					}
					else if(phid!=0 &&textField_3.getText().isEmpty())
					{
						System.out.println("delete primary");
						display=HealthSupporterBO.DeleteHealthSupporter(phid, patientId);
						desktopPane_4.setVisible(false);
					}
					else if(shid!=0 &&textField_4.getText().isEmpty())
					{
						System.out.println("delete sec");
						display=HealthSupporterBO.DeleteHealthSupporter(shid, patientId);
						desktopPane_4.setVisible(false);
					}
					else
					{
						if(phusername.equals(textField_3.getText())){
							display=HealthSupporterBO.InsertUpdateHealthSupporter(textField_3.getText(),phid,patientId,true,textField_12.getText(),"2099-12-12",textField_13.getText());
							
						}
						else
							JOptionPane.showMessageDialog(frmPatient,"Username can't be changed");
						System.out.println(display);
						if (display.equals("Health Supporter details updated successfully")||display.equals("Health Supporter tagged as a Primary health supporter")||display.equals("Health Supporter tagged successfully"))
						{
							if(!textField_4.getText().isEmpty()&&!textField_14.getText().isEmpty()&&!textField_15.getText().isEmpty()&&shid==0)
							{
								System.out.println("sec1");
								System.out.println(textField_4.getText()+ " "+0+" "+patientId+" "+textField_14.getText()+" "+textField_15.getText());
								display=HealthSupporterBO.InsertUpdateHealthSupporter(textField_4.getText(),0,patientId,false,textField_14.getText(),"2047-10-12",textField_15.getText());
								System.out.println(display);
							}
							else if(!textField_4.getText().isEmpty()&&!textField_14.getText().isEmpty()&&!textField_15.getText().isEmpty()&&shusername.equals(textField_4.getText()))
							{
								display=HealthSupporterBO.InsertUpdateHealthSupporter(textField_4.getText(),shid,patientId,false,textField_14.getText(),"2099-12-12",textField_15.getText());
							}
							else if(textField_4.getText().isEmpty()){
								desktopPane_4.setVisible(false);
							}
							else
							{
								JOptionPane.showMessageDialog(frmPatient,"Username can't be changed");
							}
							if (!(display.equals("Health Supporter details updated successfully")||display.equals("Health Supporter tagged as a Primary health supporter")||display.equals("Health Supporter tagged successfully")))
								JOptionPane.showMessageDialog(frmPatient,"Secondary Failed b");
						}
						else
							JOptionPane.showMessageDialog(frmPatient,"Primary and/or Secondary Failed");
					}
					if(display.equals("Health Supporter deleted successfully")||display.equals("Health Supporter details updated successfully")||display.equals("Health Supporter tagged as a Primary health supporter")||display.equals("Health Supporter tagged successfully"))
					{
						JOptionPane.showMessageDialog(frmPatient,"Updated Successfully && Refresh the Window");
						desktopPane_4.setVisible(false);
					}
				}
			}

			private boolean check_supporter(String string1,String string2,String string3, String string4,String string5, String string6) {
				// TODO Auto-generated method stub
				//System.out.println(string1+string2+string3+string4+string5+string6);
				if(string4.isEmpty()&&string5.isEmpty()&&string6.isEmpty())
				{
					if(string1.isEmpty()||string2.isEmpty()||string3.isEmpty())
						return true;
					else
						return false;
				}
				else if (string4.isEmpty()||string5.isEmpty()||string6.isEmpty())
					return true;
				else if(string1.isEmpty()||string2.isEmpty()||string3.isEmpty())
					return true;
				else {
					
					return false;}
			}
		});
		btnUpdate_2.setForeground(Color.BLUE);
		desktopPane_4.add(btnUpdate_2, "cell 2 10");
		
		JDesktopPane desktopPane_5 = new JDesktopPane();
		desktopPane_5.setBackground(Color.BLACK);
//		frmPatient.getContentPane().add(desktopPane_5, BorderLayout.SOUTH);
		desktopPane_5.setLayout(new MigLayout("", "[][][][48px][71px][20px][59px]", "[20px][20px][20px][20px][20px][20px][23px][23px]"));
		desktopPane_5.setVisible(false);
		
		JLabel lblNewLabel_12 = new JLabel("                      ");
		lblNewLabel_12.setBackground(Color.BLACK);
		desktopPane_5.add(lblNewLabel_12, "cell 0 0 2 1");
		
		JLabel lblNewLabel_11 = new JLabel("            ");
		lblNewLabel_11.setBackground(Color.BLACK);
		desktopPane_5.add(lblNewLabel_11, "cell 2 0");
		
		JLabel label_1 = new JLabel("Username");
		label_1.setForeground(Color.WHITE);
		desktopPane_5.add(label_1, "cell 3 0,alignx left,aligny center");
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		desktopPane_5.add(textField_5, "cell 4 0 3 1,growx,aligny top");
		
		JLabel label_5 = new JLabel("Password");
		label_5.setForeground(Color.WHITE);
		desktopPane_5.add(label_5, "cell 3 1,growx,aligny center");
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		desktopPane_5.add(textField_6, "cell 4 1 3 1,growx,aligny top");
		
		JLabel label_6 = new JLabel("Name");
		label_6.setForeground(Color.WHITE);
		desktopPane_5.add(label_6, "cell 3 2,growx,aligny center");
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		desktopPane_5.add(textField_7, "cell 4 2 3 1,growx,aligny top");
		
		textField_8 = new JTextField();
		textField_8.setToolTipText("yyyy-mm-dd");
		textField_8.setColumns(10);
		desktopPane_5.add(textField_8, "cell 4 3 3 1,growx,aligny top");
		
		JLabel label_7 = new JLabel("DOB");
		label_7.setForeground(Color.WHITE);
		desktopPane_5.add(label_7, "cell 3 3,growx,aligny center");
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		desktopPane_5.add(textField_9, "cell 4 4 3 1,growx,aligny top");
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		desktopPane_5.add(textField_10, "cell 4 5 3 1,growx,aligny top");
		
		JLabel label_8 = new JLabel("SSN");
		label_8.setForeground(Color.WHITE);
		desktopPane_5.add(label_8, "cell 3 5,growx,aligny center");
		
		JLabel label_9 = new JLabel("Address");
		label_9.setForeground(Color.WHITE);
		desktopPane_5.add(label_9, "cell 3 4,growx,aligny center");
		
		JLabel label_10 = new JLabel("Gender");
		label_10.setForeground(Color.WHITE);
		desktopPane_5.add(label_10, "cell 3 6,growx,aligny center");
		
		JRadioButton radioButton = new JRadioButton("Male");
		radioButton.setForeground(Color.WHITE);
		radioButton.setBackground(Color.BLACK);
		desktopPane_5.add(radioButton, "cell 4 6,growx,aligny top");
		
		JRadioButton radioButton_1 = new JRadioButton("Female");
		radioButton_1.setForeground(Color.WHITE);
		radioButton_1.setBackground(Color.BLACK);
		desktopPane_5.add(radioButton_1, "cell 6 6,alignx left,aligny top");
		
		JButton button = new JButton("SignUp");
		button.setForeground(Color.BLUE);
		desktopPane_5.add(button, "cell 4 7,alignx right,aligny top");
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.BLACK);
		frmPatient.setJMenuBar(menuBar);
		
		JMenuItem mntmProfile = new JMenuItem("Profile");
		mntmProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HashMap<String, String> profile = new HashMap<String, String>();
				try {
					profile = DBHandling.getUserProfile(userId);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				lblNewLabel.setText(profile.get("username"));
				textField_1.setText(profile.get("name"));
				textField_2.setText(profile.get("address"));
				textField.setText(profile.get("dob"));
				textField_11.setText(profile.get("ssn"));
				passwordField.setText("password");
				lblNewLabel_5.setText(profile.get("category"));
				if(profile.get("gender").equals("Male"))
				{
					rdbtnMale.setSelected(true);
					rdbtnFemale.setSelected(false);
				}
				else
				{
					rdbtnFemale.setSelected(true);
					rdbtnMale.setSelected(false);
				}
	//			frmPatient.remove(desktopPane);
				frmPatient.remove(desktopPane_1);
				frmPatient.remove(desktopPane_2);
				frmPatient.remove(desktopPane_3);
				frmPatient.remove(desktopPane_4);
				frmPatient.remove(desktopPane_5);
				frmPatient.getContentPane().add(desktopPane, BorderLayout.CENTER);
				desktopPane_1.setVisible(false);
				desktopPane_2.setVisible(false);
				desktopPane_3.setVisible(false);
				desktopPane_4.setVisible(false);
				desktopPane.setVisible(true);

			}
		});
		mntmProfile.setForeground(Color.WHITE);
		mntmProfile.setBackground(Color.YELLOW);
		mntmProfile.setHorizontalAlignment(SwingConstants.LEFT);
		menuBar.add(mntmProfile);
		
		JMenuItem mntmDiagnoses = new JMenuItem("Diagnoses");
		mntmDiagnoses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//	diagnosis_screen();
				comboBox_1.removeAllItems();
				comboBox.removeAllItems();
				HashMap<Integer, HashMap<String, Boolean>> map = new HashMap<Integer, HashMap<String,Boolean>>();
				try {
					map = DBHandling.getUserDiseases(patientId);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				for(int diagnosisId : map.keySet()){
					HashMap<String, Boolean> inner_map = map.get(diagnosisId);
					for(String disease : inner_map.keySet()){
						boolean val = inner_map.get(disease);
						if(val)
							comboBox_1.addItem(disease);
						else
							comboBox.addItem(disease);
	//					System.out.println(diagnosisId+" "+disease+" "+val);
					}
				}
		//		frmPatient.remove(desktopPane);
			//	frmPatient.remove(desktopPane_1);
		//		frmPatient.remove(desktopPane_2);
		//		frmPatient.remove(desktopPane_3);
		//		frmPatient.remove(desktopPane_4);
	//			frmPatient.remove(desktopPane_5);
				frmPatient.getContentPane().add(desktopPane_1, BorderLayout.CENTER);
				desktopPane.setVisible(false);
				desktopPane_2.setVisible(false);
				desktopPane_3.setVisible(false);
				desktopPane_4.setVisible(false);
				desktopPane_1.setVisible(true);

			}
		});
		mntmDiagnoses.setBackground(Color.YELLOW);
		mntmDiagnoses.setForeground(Color.WHITE);
		mntmDiagnoses.setHorizontalAlignment(SwingConstants.LEFT);
		menuBar.add(mntmDiagnoses);
		
		JMenuItem mntmAlerts = new JMenuItem("Health");
		mntmAlerts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					Object[][] data5 = DBHandling.getReadings(patientId);
					DefaultTableModel model5 = new DefaultTableModel(data5, columnNames5);
					table.setModel(model5);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				try {
					HashMap<Integer, HashMap<String, String>> hr4 = DBHandling.getHealthIndicators(patientId);
					String[] columnNames4 = {"HealthObservationName", "Metric", "Threshold", "UpperLimit", "LowerLimit", "Frequency"};
			        Object[][] data4 = new Object[hr4.size()][5];
			        Integer count4 = 0;
					for(int hrId : hr4.keySet()){
						HashMap<String, String> inner_map = hr4.get(hrId);
						Object[] temp_data = {
								inner_map.get("HealthObservationName"),
								inner_map.get("metric"),
								inner_map.get("Threshold"),
								inner_map.get("UpperLimit"),
								inner_map.get("LowerLimit"),
								inner_map.get("Frequency")		
						};
						data4[count4] = temp_data;
						count4 = count4 + 1;
					}
				
			        DefaultTableModel model4 = new DefaultTableModel(data4, columnNames4);
					
					table_3.setModel(model4);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				comboBox_2.removeAllItems();
				HashMap<Integer, HashMap<String, String>> health_obs = new HashMap<Integer, HashMap<String,String>>();
				try {
					health_obs = DBHandling.getHealthObservations(patientId);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
				for(int healthobservationid : health_obs.keySet()){
					HashMap<String, String> inner_map = health_obs.get(healthobservationid);
					comboBox_2.addItem(inner_map.get("HealthObservationName"));
											
				}
				//Patient has any disease
				boolean isWell=true;
				HashMap<Integer, HashMap<String, Boolean>> map = new HashMap<Integer, HashMap<String,Boolean>>();
				try {
					map = DBHandling.getUserDiseases(patientId);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				for(int diagnosisId : map.keySet()){
					HashMap<String, Boolean> inner_map = map.get(diagnosisId);
					for(String disease : inner_map.keySet()){
						boolean val = inner_map.get(disease);
						if(val)
							isWell=false;
						
					}
				}
				
				//Filling out table
				HashMap<Integer, HashMap<String, String>> health_indicator = new HashMap<Integer, HashMap<String,String>>();
				try {
					health_indicator = DBHandling.getHealthIndicators(patientId);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				int i=0;
				Object tableContents[][]=new Object[11][3];
				//HashMap<Integer, HashMap<String, Boolean>> map = DBHandling.getUserDiseases(patientId);
				for(int healthobservationid : health_indicator.keySet()){
					HashMap<String, String> inner_map = health_indicator.get(healthobservationid);
						String val1 = inner_map.get("HealthObservationName");
						String val2 = inner_map.get("UpperLimit");
						String val3 = inner_map.get("LowerLimit");
						String val4 = inner_map.get("Frequency");
						tableContents[i][0]=val1;
						tableContents[i][1]="U :"+val2+" L :"+val3;
						tableContents[i][2]=val4;
				//		System.out.println(i+val1+val2+val3+val4);
						i++;
						
				}
				/*
				table.setModel(new DefaultTableModel(
						tableContents,
						new String[] {
							"Health Indicator Name", "Additional  Information", "Frequency"
						}
					));*/
			//	frmPatient.remove(desktopPane);
		//		frmPatient.remove(desktopPane_1);
				//frmPatient.remove(desktopPane_2);
		//		frmPatient.remove(desktopPane_3);
		//		frmPatient.remove(desktopPane_4);
		//		frmPatient.remove(desktopPane_5);
				frmPatient.getContentPane().add(desktopPane_2, BorderLayout.CENTER);
				desktopPane.setVisible(false);
				desktopPane_1.setVisible(false);
				desktopPane_3.setVisible(false);
				desktopPane_4.setVisible(false);
				desktopPane_2.setVisible(true);

			}
		});
		mntmAlerts.setForeground(Color.WHITE);
		mntmAlerts.setBackground(Color.YELLOW);
		mntmAlerts.setHorizontalAlignment(SwingConstants.LEFT);
		menuBar.add(mntmAlerts);
		
		JMenuItem mntmAlerts_1 = new JMenuItem("Alerts");
		mntmAlerts_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		//		frmPatient.remove(desktopPane);
		//		frmPatient.remove(desktopPane_1);
		//		frmPatient.remove(desktopPane_2);
				//frmPatient.remove(desktopPane_3);
		//		frmPatient.remove(desktopPane_4);
		//		frmPatient.remove(desktopPane_5);
				
				boolean res;
				try {
					res = DBHandling.generateInactivityAlertFinal(patientId);
					if(!res){
//						JOptionPane.showMessageDialog(frmPatient,"Error generating alerts");
					}
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				res = AlertsBO.GenerateOverTheLimitAlerts(patientId);
				if(!res){
					JOptionPane.showMessageDialog(frmPatient,"Error generating alerts");
				}
				
				frmPatient.getContentPane().add(desktopPane_3, BorderLayout.CENTER);
				desktopPane.setVisible(false);
				desktopPane_1.setVisible(false);
				desktopPane_2.setVisible(false);
				desktopPane_4.setVisible(false);
				desktopPane_3.setVisible(true);
				try {
					data = AlertsBO.getAlerts(patientId);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		        DefaultTableModel model2 = new DefaultTableModel(data, columnNames);
				table_2.setModel(model2);

			}
		});
		mntmAlerts_1.setBackground(Color.YELLOW);
		mntmAlerts_1.setForeground(Color.WHITE);
		mntmAlerts_1.setHorizontalAlignment(SwingConstants.LEFT);
		menuBar.add(mntmAlerts_1);
		
		JMenuItem mntmHealthSupporter = new JMenuItem("Supporter");
		mntmHealthSupporter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<HealthSupporterBO> lisths=HealthSupporterBO.GetListOfHSForPatient(patientId);
				phid=shid=0;
				phusername=shusername=phauthdate=phcontact=shauthdate=shcontact=null;
				textField_3.setText(null);
				lblNewLabel_8.setText(null);
				textField_12.setText(null);
				textField_13.setText(null);
				textField_4.setText(null);
				lblNewLabel_13.setText(null);
				textField_14.setText(null);
				textField_15.setText(null);
				if(lisths!=null)
				for(int i=0;i<lisths.size();i++)
				{
				//	System.out.println(lisths.get(i).isPrimary);
	//				private int phid,shid;
//					private String phusername,shusername,phauthdate,phauthtill,shauthdate,shauthtill;

					if(lisths.get(i).isPrimary.compareToIgnoreCase("y")==0)
					{
						textField_3.setText(lisths.get(i).username);
						lblNewLabel_8.setText(lisths.get(i).name);
						textField_12.setText(lisths.get(i).authorizedOn);
						textField_13.setText(lisths.get(i).contact);
						phid=lisths.get(i).healthSupporterId;
						System.out.println("phid "+phid);
						phusername=lisths.get(i).username;
						phauthdate=lisths.get(i).authorizedOn;
						phcontact=lisths.get(i).contact;
					}
					else
					{
						textField_4.setText(lisths.get(i).username);
						lblNewLabel_13.setText(lisths.get(i).name);
						textField_14.setText(lisths.get(i).authorizedOn);
						textField_15.setText(lisths.get(i).authorizedTill);
						shid=lisths.get(i).healthSupporterId;
						shusername=lisths.get(i).username;
						shauthdate=lisths.get(i).authorizedOn;
						shcontact=lisths.get(i).contact;
					}
				}
		//		frmPatient.remove(desktopPane);
		//		frmPatient.remove(desktopPane_1);
		//		frmPatient.remove(desktopPane_2);
		//		frmPatient.remove(desktopPane_3);
				//frmPatient.remove(desktopPane_4);
		//		frmPatient.remove(desktopPane_5);
				frmPatient.getContentPane().add(desktopPane_4, BorderLayout.CENTER);
				desktopPane.setVisible(false);
				desktopPane_1.setVisible(false);
				desktopPane_2.setVisible(false);
				desktopPane_3.setVisible(false);
				desktopPane_4.setVisible(true);
			}
		});
		mntmHealthSupporter.setForeground(Color.WHITE);
		mntmHealthSupporter.setBackground(Color.YELLOW);
		mntmHealthSupporter.setHorizontalAlignment(SwingConstants.LEFT);
		menuBar.add(mntmHealthSupporter);
		
		JMenuItem mntmLogout = new JMenuItem("Logout");
		mntmLogout.setBackground(Color.YELLOW);
		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmLogout.setForeground(Color.RED);
		mntmLogout.setHorizontalAlignment(SwingConstants.LEFT);
		menuBar.add(mntmLogout);
	//	desktopPane.setVisible(true);
	}
	private int check(String string, String string2, String string3, String string4, String string5) {
		// TODO Auto-generated method stub
		if (string.isEmpty() || string2.isEmpty() || string3.isEmpty()|| string4.isEmpty() ||string5.isEmpty())
		return 0;
		return 1;
	}
	
	private String getSelectedButton()
	{  
	    for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
	            AbstractButton button = buttons.nextElement();
	            if (button.isSelected()) {
	                return button.getText();
	            }
	        }
	return null;
	}
}
