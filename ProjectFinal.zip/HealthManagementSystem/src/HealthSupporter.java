import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JToolBar;
import java.awt.BorderLayout;
import javax.swing.JInternalFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class HealthSupporter {

	JFrame frame;
	private JPanel Home;
	private JPanel Profile;
	private JPanel Patient;
	private JPanel Update;
	private JTextField txtName;
	private JTextField txtDob;
	private JTextField txtGender;
	private JTextField txtAddress;
	private JTextField txtSssnnn;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					HealthSupporter window = new HealthSupporter(8);
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public HealthSupporter(int user_id) throws SQLException {
		initialize(user_id);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	public ResultSet getProfileDetails(int id) {
		ResultSet rs = null;
		try{
			ConnectionToOracle con=new ConnectionToOracle();
			 PreparedStatement pstmt = null;
			 Connection c1=con.returnConnection();
			 String query = "select * from users where id=?;";
			 pstmt = c1.prepareStatement(query);
		      pstmt.setInt(1, id);
		      //System.out.println(String.valueOf(passwordField.getPassword()));
		      rs = pstmt.executeQuery();
		      if(rs.next()==false){
		    	  JOptionPane.showMessageDialog(frame,"Wrong Username/Password");
		      }
		       pstmt.close();
			con.connectionClose();
			}
			catch(SQLException e1){
				System.out.println("error while fetching profile data from db");
				}
		return rs;
		
	}
		
	
	
	private void initialize(int user_id) throws SQLException {
		int hid = HealthSupporterBO.getHealthSupporterIdForUserId(user_id);
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		Home = new JPanel();
		Home.setBackground(Color.BLACK);
		frame.getContentPane().add(Home, "name_1187838165735951");
		
		JButton btnHome = new JButton("Home");
		btnHome.setForeground(Color.RED);
		btnHome.setBackground(Color.BLACK);
		
		JButton btnProfile = new JButton("Profile");
		btnProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Profile.setVisible(true);
				Home.setVisible(false);
			}
		});
		
		JButton btnPatient = new JButton("Patient");
		btnPatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient.setVisible(true);
				Home.setVisible(false);
			}
		});
		
		JLabel lblWelcomeToHealth = new JLabel("Welcome to Health Support Management System");
		lblWelcomeToHealth.setForeground(Color.YELLOW);
		GroupLayout gl_Home = new GroupLayout(Home);
		gl_Home.setHorizontalGroup(
			gl_Home.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Home.createSequentialGroup()
					.addGroup(gl_Home.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_Home.createSequentialGroup()
							.addContainerGap()
							.addComponent(btnHome)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnProfile)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnPatient))
						.addGroup(gl_Home.createSequentialGroup()
							.addGap(17)
							.addComponent(lblWelcomeToHealth, GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(114, Short.MAX_VALUE))
		);
		gl_Home.setVerticalGroup(
			gl_Home.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Home.createSequentialGroup()
					.addGap(46)
					.addGroup(gl_Home.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnHome)
						.addComponent(btnProfile)
						.addComponent(btnPatient))
					.addGap(26)
					.addComponent(lblWelcomeToHealth, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(146, Short.MAX_VALUE))
		);
		Home.setLayout(gl_Home);
		
		Profile = new JPanel();
		Profile.setBackground(Color.BLACK);
		frame.getContentPane().add(Profile, "name_1188548538699422");
		
		JButton button = new JButton("Home");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(true);
				Profile.setVisible(false);
			}
		});
		
		JButton button_1 = new JButton("Profile");
		button_1.setForeground(Color.RED);
		
		JButton button_2 = new JButton("Patient");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient.setVisible(true);
				Profile.setVisible(false);
			}
		});
		
		JLabel lblName = new JLabel("Name :");
		lblName.setForeground(Color.WHITE);
		
		JLabel lblDob = new JLabel("D.O.B. :");
		lblDob.setForeground(Color.WHITE);
		
		JLabel lblGender = new JLabel("Gender :");
		lblGender.setForeground(Color.WHITE);
		
		JLabel lblAddress = new JLabel("Address :");
		lblAddress.setForeground(Color.WHITE);
		
		HashMap<String, String> userProfile = DBHandling.getUserProfile(user_id);
		String name = userProfile.get("name");
		String dob = userProfile.get("dob");
		String gender = userProfile.get("gender");
		String address = userProfile.get("address");
		String ssn = userProfile.get("ssn");
		String password = userProfile.get("password");
		
		
		JLabel label = new JLabel(name);
		label.setForeground(Color.GREEN);
		
		JLabel lblNewLabel = new JLabel(dob);
		lblNewLabel.setForeground(Color.GREEN);
		
		JLabel lblNewLabel_1 = new JLabel(gender);
		lblNewLabel_1.setForeground(Color.GREEN);
		
		JLabel lblNewLabel_2 = new JLabel(address);
		lblNewLabel_2.setForeground(Color.GREEN);
		
		JLabel lblSsn = new JLabel("Ssn :");
		lblSsn.setForeground(Color.WHITE);
		
		JLabel lblNewLabel_3 = new JLabel(ssn);
		lblNewLabel_3.setForeground(Color.GREEN);
		
		
		
		JButton btnUpdateProfile = new JButton("Update Profile");
		btnUpdateProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Update.setVisible(true);
				Profile.setVisible(false);
			}
		});
		
		
		GroupLayout gl_Profile = new GroupLayout(Profile);
		gl_Profile.setHorizontalGroup(
			gl_Profile.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Profile.createSequentialGroup()
					.addGroup(gl_Profile.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_Profile.createSequentialGroup()
							.addGap(58)
							.addGroup(gl_Profile.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_Profile.createSequentialGroup()
									.addGroup(gl_Profile.createParallelGroup(Alignment.LEADING)
										.addComponent(lblName)
										.addComponent(lblDob)
										.addComponent(lblGender))
									.addGap(26)
									.addGroup(gl_Profile.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_1)
										.addComponent(lblNewLabel)
										.addComponent(label)))
								.addGroup(gl_Profile.createSequentialGroup()
									.addGroup(gl_Profile.createParallelGroup(Alignment.LEADING)
										.addComponent(lblAddress)
										.addComponent(lblSsn))
									.addGap(18)
									.addGroup(gl_Profile.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_3)
										.addComponent(lblNewLabel_2)))))
						.addGroup(gl_Profile.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_Profile.createParallelGroup(Alignment.TRAILING)
								.addComponent(btnUpdateProfile)
								.addGroup(gl_Profile.createSequentialGroup()
									.addComponent(button)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(button_1)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(button_2)))))
					.addContainerGap(261, Short.MAX_VALUE))
		);
		gl_Profile.setVerticalGroup(
			gl_Profile.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Profile.createSequentialGroup()
					.addGap(46)
					.addGroup(gl_Profile.createParallelGroup(Alignment.BASELINE)
						.addComponent(button)
						.addComponent(button_1)
						.addComponent(button_2))
					.addGap(18)
					.addGroup(gl_Profile.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblName)
						.addComponent(label, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Profile.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDob)
						.addComponent(lblNewLabel))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Profile.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblGender)
						.addComponent(lblNewLabel_1))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Profile.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAddress)
						.addComponent(lblNewLabel_2))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Profile.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSsn)
						.addComponent(lblNewLabel_3))
					.addGap(18)
					.addComponent(btnUpdateProfile)
					.addContainerGap(34, Short.MAX_VALUE))
		);
		Profile.setLayout(gl_Profile);
		
		Patient = new JPanel();
		Patient.setBackground(Color.BLACK);
		frame.getContentPane().add(Patient, "name_1188588079168258");
		
		JButton button_4 = new JButton("Home");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(true);
				Patient.setVisible(false);
			}
		});
		
		JButton button_5 = new JButton("Profile");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Profile.setVisible(true);
				Patient.setVisible(false);
			}
		});
		
		JButton button_6 = new JButton("Patient");
		button_6.setForeground(Color.RED);
		
		JLabel lblLstOfPatients = new JLabel("List of Patients : ");
		lblLstOfPatients.setForeground(Color.YELLOW);
		
		ArrayList<PatientBO> patientLists = HealthSupporterBO.GetListOfPatientsForHealthSupporter(hid);
		HashMap<String, Integer> HSPatientLists = new HashMap<String, Integer>();
		for (PatientBO patient : patientLists){
			HSPatientLists.put(patient.name, (int) patient.userId);
		}
		
		JComboBox comboBox = new JComboBox();
		
		if (HSPatientLists != null){
			Iterator it = HSPatientLists.keySet().iterator();
			while(it.hasNext())
			{
				comboBox.addItem(it.next());
			}
		}
		JButton btnShowAlerts = new JButton("View Patient Details");
		btnShowAlerts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (HSPatientLists != null){
					Integer pid = HSPatientLists.get(comboBox.getSelectedItem());
					Patient p;
					try {
						p = new Patient(pid, user_id, true);
						p.frmPatient.setVisible(true);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		
		JButton btnShowReadings = new JButton("Update Recommendations");
		btnShowReadings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (HSPatientLists != null){
					Integer pid = HSPatientLists.get(comboBox.getSelectedItem());
					Recommendation r;
					try {
						r = new Recommendation(pid);
						r.frame.setVisible(true);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		GroupLayout gl_Patient = new GroupLayout(Patient);
		gl_Patient.setHorizontalGroup(
			gl_Patient.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Patient.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_Patient.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_Patient.createSequentialGroup()
							.addComponent(button_4)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_5)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_6)
							.addGap(82))
						.addGroup(gl_Patient.createSequentialGroup()
							.addComponent(btnShowReadings)
							.addGap(18)
							.addComponent(btnShowAlerts)
							.addPreferredGap(ComponentPlacement.RELATED))
						.addGroup(gl_Patient.createSequentialGroup()
							.addGap(113)
							.addComponent(lblLstOfPatients)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox, 0, 169, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(98))
		);
		gl_Patient.setVerticalGroup(
			gl_Patient.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Patient.createSequentialGroup()
					.addGap(46)
					.addGroup(gl_Patient.createParallelGroup(Alignment.BASELINE)
						.addComponent(button_4)
						.addComponent(button_5)
						.addComponent(button_6))
					.addGap(36)
					.addGroup(gl_Patient.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLstOfPatients)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Patient.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnShowReadings)
						.addComponent(btnShowAlerts))
					.addGap(105))
		);
		Patient.setLayout(gl_Patient);
	
		Update = new JPanel();
		Update.setBackground(Color.BLACK);
		frame.getContentPane().add(Update, "name_1208707136183168");
		
		JButton button_8 = new JButton("Home");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(true);
				Update.setVisible(false);
			}
		});
		JButton button_9 = new JButton("Profile");
		button_9.setForeground(Color.RED);
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Profile.setVisible(true);
				Update.setVisible(false);
			}
		});
		
		JButton button_10 = new JButton("Patient");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient.setVisible(true);
				Update.setVisible(false);
			}
		});
		
		JLabel label_1 = new JLabel("Address :");
		label_1.setForeground(Color.WHITE);
		
		JLabel label_3 = new JLabel("Name :");
		label_3.setForeground(Color.WHITE);
		
		JLabel label_4 = new JLabel("D.O.B. :");
		label_4.setForeground(Color.WHITE);
		
		JLabel label_5 = new JLabel("Gender :");
		label_5.setForeground(Color.WHITE);
		
		txtName = new JTextField();
		txtName.setText(name);
		txtName.setColumns(10);
		
		txtDob = new JTextField();
		txtDob.setText(dob.toString());
		txtDob.setColumns(10);
		
		txtGender = new JTextField();
		txtGender.setText(gender);
		txtGender.setColumns(10);
		
		txtAddress = new JTextField();
		txtAddress.setText(address);
		txtAddress.setColumns(10);

		JLabel lblSsn_1 = new JLabel("Ssn :");
		lblSsn_1.setForeground(Color.WHITE);
		
		txtSssnnn = new JTextField();
		txtSssnnn.setText(ssn);
		txtSssnnn.setColumns(10);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Boolean res = DBHandling.insertUpdatePatient(user_id, name, dob,
							 gender, address, "xyy", password, ssn);
						if (!res){
							JOptionPane.showMessageDialog(frame, "Failed Updating");
						}	
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(frame, "Failed Updating");
				}
				
				Update.setVisible(false);
				Profile.setVisible(true);
			}
		});
		
		GroupLayout gl_Update = new GroupLayout(Update);
		gl_Update.setHorizontalGroup(
			gl_Update.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Update.createSequentialGroup()
					.addGroup(gl_Update.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_Update.createSequentialGroup()
							.addContainerGap()
							.addComponent(button_8)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_9)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_10))
						.addGroup(gl_Update.createSequentialGroup()
							.addGap(58)
							.addGroup(gl_Update.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_Update.createSequentialGroup()
									.addComponent(label_5)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(txtGender, 133, 133, 133))
								.addGroup(gl_Update.createSequentialGroup()
									.addGroup(gl_Update.createParallelGroup(Alignment.LEADING)
										.addComponent(label_4)
										.addComponent(label_3))
									.addGap(18)
									.addGroup(gl_Update.createParallelGroup(Alignment.LEADING)
										.addComponent(txtName, 133, 133, 133)
										.addComponent(txtDob, 133, 133, 133)))
								.addGroup(gl_Update.createSequentialGroup()
									.addGroup(gl_Update.createParallelGroup(Alignment.LEADING)
										.addComponent(label_1)
										.addComponent(lblSsn_1))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addGroup(gl_Update.createParallelGroup(Alignment.LEADING)
										.addComponent(txtSssnnn, 133, 133, 133)
										.addComponent(btnUpdate)
										.addComponent(txtAddress, 133, 133, 133))))))
					.addGap(194))
		);
		gl_Update.setVerticalGroup(
			gl_Update.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Update.createSequentialGroup()
					.addGap(46)
					.addGroup(gl_Update.createParallelGroup(Alignment.BASELINE)
						.addComponent(button_8)
						.addComponent(button_9)
						.addComponent(button_10))
					.addGap(18)
					.addGroup(gl_Update.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(txtName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Update.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_4)
						.addComponent(txtDob, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Update.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_5)
						.addComponent(txtGender, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Update.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(txtAddress, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_Update.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSsn_1)
						.addComponent(txtSssnnn, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(btnUpdate))
		);
		Update.setLayout(gl_Update);
		
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}
}
