
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserBO {
	public int userId;
	public String name;
	public String dob;
	public String gender;
	public String address;
	public String username;
	public String password;
	public String ssn;
	
	
	public UserBO(){
		
	}
	
	
	public UserBO(int userId, String name, String dob, String gender, String address, String username,
			String password, String ssn){
		this.userId = userId;
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		this.address = address;
		this.username = username;
		this.password = password;
		this.ssn = ssn;
	}
	

	// Description : Methods to get the userID from a username
	public static int getUserIdFromUserName(String username) {
		int result = 0;

		ConnectionToOracle con = new ConnectionToOracle();

		try {
			
			PreparedStatement pstmt = null;
			Connection c1 = con.returnConnection();
			String query = "select userid from users where username=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setString(1, username);

			ResultSet rs = pstmt.executeQuery();
			
			if(rs != null && rs.next())
				result = rs.getInt("userid");
			
			if(rs != null)
				rs.close();
			
			pstmt.close();
			
			con.connectionClose();
			
		} catch (SQLException e1) {
			return -1;
		} finally {
			if (con != null)
				con.connectionClose();
		}

		return result;
		
	}

}