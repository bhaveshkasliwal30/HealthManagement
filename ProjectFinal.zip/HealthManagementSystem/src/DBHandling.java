import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import oracle.jdbc.internal.OracleTypes;

public class DBHandling {

	// Inserts new patient or updates value of existing patient
	// for insert put userID = 0
	public static boolean insertUpdatePatient(int userID, String name, String dob, String gender, String address,
			String username, String password, String ssn) throws SQLException {
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = null;
		CallableStatement cStmt = null;
		try {
			c1 = con.returnConnection();
			cStmt = c1.prepareCall("{call InsertUpdatePatient(?, ?, ?, ?, ?, ?, ?, ?)}");
			cStmt.setInt(1, userID);
			cStmt.setString(2, name);
			cStmt.setDate(3, java.sql.Date.valueOf(dob));
			cStmt.setString(4, gender);
			cStmt.setString(5, address);
			cStmt.setString(6, username);
			cStmt.setString(7, password);
			cStmt.setString(8, ssn);
			int result = cStmt.executeUpdate();
			cStmt.close();
			c1.close();
			con.close();
			return (result >= 1) ? true : false;
		} catch (Exception ex) {
			cStmt.close();
			c1.close();
			con.close();
			return false;
		}

	}

	// Returns -1 if invalid credentials are entered.
	public static int authenticateUser(String username, String password, boolean isHealthSupporter)
			throws SQLException {
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			c1 = con.returnConnection();
			String query = "select userid from users where username=? and password=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			int userId = -1;
			if (rs.next()) {
				userId = rs.getInt(1);
			}
			if (isHealthSupporter) {
				// check if user is healthsupporter
				query = "select healthsupporterid from healthsupporter where userid=?";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, userId);
				rs = pstmt.executeQuery();
				if (!rs.next()) { // if no result is found, then invalid
									// credentials have been entered
					userId = -1;
				}
			}
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return userId;
		} catch (Exception ex) {
			c1.close();
			con.close();
			System.out.println("Error while authenticating user. Error: " + ex.getMessage());
			return -1;
		}
	}

	// returns a hashmap of user's profile
	public static HashMap<String, String> getUserProfile(int userId) throws SQLException {
		HashMap<String, String> profile = new HashMap<>();
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			c1 = con.returnConnection();
			String query = "select * from users where userid=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			// assumed that this query always will find a valid user profile and
			// returns only 1 row
			rs.next();
			profile.put("name", rs.getString(2));
			profile.put("dob", rs.getDate(3).toString());
			profile.put("gender", rs.getString(4));
			profile.put("address", rs.getString(5));
			profile.put("username", rs.getString(6));
			profile.put("password", rs.getString(7));
			profile.put("ssn", rs.getString(8));

			// get well/sick status
			int patientId = rs.getInt(1);
			profile.put("patientId", String.valueOf(patientId));
			query = "select patienttype from patients where patientid=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			rs.next();
			String patientType = rs.getString(1);
			profile.put("category", patientType);
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return profile;
		} catch (Exception ex) {
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return profile;
		}
	}

	// returns a hashmap (diseaseId, (disease, flag)) for a given userId
	public static HashMap<Integer, HashMap<String, Boolean>> getUserDiseases(int patientId) throws SQLException {
		HashMap<Integer, HashMap<String, Boolean>> map = new HashMap<>();
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		CallableStatement cStmt = null;
		ResultSet rs = null;
		try {
			c1 = con.returnConnection();
			cStmt = c1.prepareCall("{call getUserDiseases(?, ?)}");
			cStmt.setInt(1, patientId);
			cStmt.registerOutParameter(2, OracleTypes.CURSOR);
			cStmt.executeQuery();
			rs = (ResultSet) cStmt.getObject(2);
			while (rs.next()) {
				HashMap<String, Boolean> temp = new HashMap<>();
				temp.put(rs.getString(2), (rs.getInt(3) == 0) ? false : true);
				map.put(rs.getInt(1), temp);
			}
			cStmt.close();
			rs.close();
			c1.close();
			con.close();
			return map;
		} catch (Exception ex) {
			cStmt.close();
			rs.close();
			c1.close();
			con.close();
			System.out.println("Error while retrieving user diseases.Error: " + ex.getMessage());
			return map;
		}
	}

	// adds a disease for a given patient. Give diagnosed on as yyy-mm-dd format
	// or ""
	public static boolean addDisease(int patientId, int diagnosisId, String diagnosedOn) throws SQLException {
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		try {
			// cannot add a disease unless atleast 1 health-supporter is
			// associated with it
			if (getHealthSupporterNumber(patientId) == 0) {
				System.out.println("no health supporter added");
				c1.close();
				con.close();
				return false;
			}
			c1 = con.returnConnection();
			String query = "insert into patientdiagnosis (patientid, diagnosisId, diagnosedOn, isActive) values(?,?,?,?)";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			pstmt.setInt(2, diagnosisId);
			if (diagnosedOn.compareTo("") == 0)
				pstmt.setTimestamp(3, getCurrentTimeStamp());
			else
				pstmt.setDate(3, java.sql.Date.valueOf(diagnosedOn));
			pstmt.setString(4, "Y");
			int result = pstmt.executeUpdate();
			// update patient-type
			query = "update patients set patienttype=? where patientid = ?";
			pstmt = c1.prepareStatement(query);
			pstmt.setString(1, "Sick");
			pstmt.setInt(2, patientId);
			result = pstmt.executeUpdate();
			pstmt.close();
			con.close();
			return (result == 0) ? false : true;
		} catch (Exception ex) {
			pstmt.close();
			c1.close();
			con.close();
			System.out.println("Error while adding a disease. Error: " + ex.getMessage());
			return false;
		}
	}

	public static boolean removeDisease(int patientId, int diagnosisId) throws SQLException {

		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			// get disease count
			String query = "select count(*) from patientdiagnosis where patientid=? and isactive=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			pstmt.setString(2, "Y");
			rs = pstmt.executeQuery();
			int numDiseases = 0;
			if (rs.next()) {
				numDiseases = rs.getInt(1);
			}
			if (numDiseases == 1) {
				// update patient
				query = "update patients set patienttype=? where patientid = ?";
				pstmt = c1.prepareStatement(query);
				pstmt.setString(1, "Well");
				pstmt.setInt(2, patientId);
				result = pstmt.executeUpdate();
				System.out.println("Updated patienttype result = " + result);
				if (result == 0) {
					pstmt.close();
					rs.close();
					c1.close();
					con.close();
					return false;
				}
			}
			// remove disease
			query = "delete from patientdiagnosis where patientid=? and diagnosisid=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			pstmt.setInt(2, diagnosisId);
			result = pstmt.executeUpdate();
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return (result == 0) ? false : true;
		} catch (Exception ex) {
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			System.out.println("Error while removing diseases. Error: " + ex.getMessage());
			return false;
		}
	}

	// returns number of health-supporters associated with a patient
	public static int getHealthSupporterNumber(int patientId) throws SQLException {
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String query = "select count(*) from hspmap where patientid = ?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			int num = 0;
			if (rs.next()) {
				num = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
			return num;
		} catch (Exception ex) {
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
			System.out.println("Error while retrieving health-supporter-number. Error: " + ex.getMessage());
			return 0;
		}
	}

	public static boolean removeHealthSupporter(int patientId, int healthsupporterId) throws SQLException {
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			int num = getHealthSupporterNumber(patientId);
			System.out.println("health supporter number: " + num);
			if (num == 1) {
				c1.close();
				con.close();
				return false;
			}

			String query = "select isPrimary from hspmap where patientid = ? and healthsupporterid = ?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			pstmt.setInt(2, healthsupporterId);
			rs = pstmt.executeQuery();
			String isPrimary = "N";
			if (rs.next())
				isPrimary = rs.getString(1);

			System.out.println("Is healthSupporter primary: " + isPrimary);
			if (isPrimary.equals("Y")) {
				// get a non primary health supporter and make him as primary
				query = "select min(healthsupporterid) from hspmap where patientid = ? and isPrimary='N'";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				rs = pstmt.executeQuery();
				int hsId = 0;
				if (rs.next())
					hsId = rs.getInt(1);
				System.out.println("non primary hsid = " + hsId);
				// remove primary health supporter
				query = "delete from hspmap where patientid = ? and healthsupporterid = ? and isPrimary = ?";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, healthsupporterId);
				pstmt.setString(3, "Y");
				int result = pstmt.executeUpdate();
				if (result == 0) {
					pstmt.close();
					rs.close();
					c1.close();
					con.close();
					return false;
				}
				// make secondary health supporter as primary
				query = "update hspmap set isPrimary = ? where patientid = ? and healthsupporterid = ?";
				pstmt = c1.prepareStatement(query);
				pstmt.setString(1, "Y");
				pstmt.setInt(2, patientId);
				pstmt.setInt(3, hsId);
				result = pstmt.executeUpdate();
				pstmt.close();
				rs.close();
				c1.close();
				con.close();
				return (result == 0) ? false : true;
			} else {
				query = "delete from hspmap where patientid = ? and healthsupporterid = ? and isPrimary = ?";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, healthsupporterId);
				pstmt.setString(3, "N");
				int result = pstmt.executeUpdate();
				rs.close();
				pstmt.close();
				c1.close();
				con.close();
				return (result == 0) ? false : true;
			}
		} catch (Exception ex) {
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			System.out.println("error while removing health supporters. Error: " + ex.getMessage());
			return false;
		}

	}

	public static HashMap<Integer, ArrayList<String>> getHealthSupporters(int patientId) throws SQLException {
		HashMap<Integer, ArrayList<String>> health_supporters = new HashMap<>();
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			// get all the health supporters
			String query = "select * from hspmap where patientId=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int hs_id = rs.getInt(2);
				ArrayList<String> list = new ArrayList<>();
				list.add(rs.getString(3));
				list.add(rs.getString(4));
				list.add(rs.getString(5));
				health_supporters.put(hs_id, list);
			}
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
			return health_supporters;
		} catch (Exception ex) {
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
			System.out.println("error while getting health supporters. Error: " + ex.getMessage());
			return health_supporters;
		}
	}

	public static boolean addReading(int patientId, int healthObsId, int readingValue, String observationtime,
			String comments) throws ParseException {
		int result = 0;
		ConnectionToOracle con;
		CallableStatement cStmt;
		Connection c1;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = format.parse(observationtime);
		long timestamp = date.getTime();

		try {
			con = new ConnectionToOracle();
			c1 = con.returnConnection();
			cStmt = c1.prepareCall("{call InsertReading(?, ?, ?, ?, ?)}");
			cStmt.setInt(1, patientId);
			cStmt.setInt(2, readingValue);
			cStmt.setInt(3, healthObsId);
			cStmt.setTimestamp(4, new java.sql.Timestamp(timestamp));
			cStmt.setString(5, comments);
			result = cStmt.executeUpdate();
			cStmt.close();
			c1.close();
			con.connectionClose();

		} catch (Exception E) {
			System.out.println("Exception while adding a reading " + E.getMessage());
		}
		if (result == 0)
			return false;
		return true;
	}

	public static HashMap<Integer, HashMap<String, String>> getHealthObservations(int patientId) throws SQLException {
		HashMap<Integer, HashMap<String, String>> health_obs = new HashMap<>();
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//String query = "select * from healthobservations";
			String query = "SELECT ho.* FROM PATIENTDIAGNOSIS pd INNER JOIN HEALTHRECOMMENDATIONS rec ON((rec.DIAGNOSISID = pd.DIAGNOSISID or "
							+ " rec.DIAGNOSISID = 0) AND rec.PATIENTID IS NULL) INNER JOIN HEALTHOBSERVATIONS ho ON(ho.HEALTHOBSERVATIONID = "
							+ " rec.HEALTHOBSERVATIONID)"
							+ "WHERE pd.PATIENTID = ? UNION"
							+ " SELECT ho.* FROM HEALTHRECOMMENDATIONS rec INNER JOIN HEALTHOBSERVATIONS ho ON(ho.HEALTHOBSERVATIONID = "
							+ " rec.HEALTHOBSERVATIONID)"
							+ "WHERE rec.DIAGNOSISID = 0";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int hoid = rs.getInt(1);
				HashMap<String, String> attr = new HashMap<>();
				attr.put("HealthObservationName", rs.getString(2));
				attr.put("Metric", rs.getString(4));
				attr.put("Description", rs.getString(5));
				attr.put("IsOrdinal", rs.getString(6));
				health_obs.put(hoid, attr);
			}
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
		} catch (Exception E) {
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
			System.out.println("error while fetching health observations, error: " + E.getMessage());
		}
		return health_obs;
	}

	// Retrieves a patient's health recommendations
	public static HashMap<Integer, HashMap<String, String>> getHealthIndicators(int patientId) throws SQLException {

		HashMap<Integer, HashMap<String, String>> health_indicator = new HashMap<>();
		HashMap<Integer, String> ho_name_map = new HashMap<Integer, String>();
		ArrayList<Integer> ordinals = new ArrayList<Integer>();
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			// get names of health observations
			String query = "select * from healthobservations";
			pstmt = c1.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ho_name_map.put(rs.getInt(1), rs.getString(2));
				if (rs.getString(4).equals("Ordinal")) {
					ordinals.add(rs.getInt(1));
				}
			}
			System.out.println(ho_name_map);

			// check if patient is well/sick
			query = "select patienttype from patients where patientid=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			String isWell = (rs.next()) ? rs.getString(1) : "Well";
			if (isWell.equals("Well")) {
				System.out.println("patient is well");
				query = "select * from ( select a.*, ROW_NUMBER() OVER (PARTITION BY a.HEALTHOBSERVATIONID ORDER BY a.frequency) AS freq from (select * from healthrecommendations where patientid=? and diagnosisid=0)a )b "
						+ " where b.freq= 1 union"
						+ " select healthrecommendations.*, 0 as freq from healthrecommendations where patientid is null and diagnosisid=0"
						+ " and HEALTHOBSERVATIONID not in (select HEALTHOBSERVATIONID from healthrecommendations where patientid=? and diagnosisid=0)";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, patientId);
				rs = pstmt.executeQuery();
			} else {
				System.out.println("patient is sick");
				query = " select * from ( select a.*, ROW_NUMBER() OVER (PARTITION BY a.HEALTHOBSERVATIONID ORDER BY a.frequency) AS freq from"
						+ "( select * from healthrecommendations where patientid=? and diagnosisid in (select diagnosisid from patientdiagnosis where "
						+ " patientid=? and isactive='Y') )a )b" + " where b.freq= 1 union"
						+ " select healthrecommendations.*, 0 as freq from healthrecommendations where patientid is null and diagnosisid in (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y')"
						+ " and HEALTHOBSERVATIONID not in (select HEALTHOBSERVATIONID from healthrecommendations where patientid=? and diagnosisid in "
						+ " (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y') ) 	";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, patientId);
				pstmt.setInt(3, patientId);
				pstmt.setInt(4, patientId);
				pstmt.setInt(5, patientId);
				rs = pstmt.executeQuery();
			}

			while (rs.next()) {
				int ho_id = rs.getInt(2);
				System.out.println(ho_id);
				System.out.println("Freq : " + rs.getInt(8) + " Threshold " + rs.getInt(9));
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("AlertThreshold", rs.getString(5));
				map.put("UpperLimit", rs.getString(6));
				map.put("LowerLimit", rs.getString(7));
				map.put("Frequency", rs.getString(8));
				map.put("InactivityThreshold", rs.getString(9));
				map.put("ConsecutiveReadings", rs.getString(10));
				health_indicator.put(ho_id, map);

			}
			for (int hid : health_indicator.keySet()) {
				HashMap<String, String> attribs = health_indicator.get(hid);
				attribs.put("HealthObservationName", ho_name_map.get(hid));
				health_indicator.put(hid, attribs);
			}
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return health_indicator;
		} catch (Exception ex) {
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			System.out.println("Some error in getting health recommendations");
			return health_indicator;
		}

	}

	public static boolean generateInactivityAlertFinal(int patientId) throws SQLException {

		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			String query = "insert into ALERTS select alert_id_final, alert_type,null,current_timestamp,null,null,readingid,?, concat('Inactivity to record observations for ',HEALTHOBSERVATIONNAME),null from ( select alert_id+rn as alert_id_final, alert_id_g.* from ( select final.*, ROW_NUMBER() OVER (PARTITION BY alert_id order by readingid) AS rn from ( select (Select NVL(max(alertid), 0) from alerts)as alert_id, 2 as alert_type,readingid, HEALTHOBSERVATIONNAME from ( select * from ( ( select r2.healthobservationid,max(r2.readingid) as readingid from readings r2 where (r2.HEALTHOBSERVATIONID,r2.PATIENTID) not in( select r.HEALTHOBSERVATIONID,r.patientid from readings r, ( select * from ( select a.*, ROW_NUMBER() OVER (PARTITION BY a.HEALTHOBSERVATIONID ORDER BY a.frequency) AS freq from ( select * from healthrecommendations where patientid=? and diagnosisid in (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y') )a )b where b.freq= 1 union select healthrecommendations.*, 0 as freq from healthrecommendations where patientid is null and diagnosisid in (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y') and HEALTHOBSERVATIONID not in (select HEALTHOBSERVATIONID from healthrecommendations where patientid=? and diagnosisid in (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y') ) ) temp1 where r.HEALTHOBSERVATIONID=temp1.HEALTHOBSERVATIONID and r.patientid=temp1.patientid and temp1.patientid=? and current_timestamp-(temp1.frequency+temp1.frequency*.01*temp1.inactivitythreshold)<r.OBSERVATIONTIME) and r2.PATIENTID=? group by r2.healthobservationid)a inner join HEALTHOBSERVATIONs ho on ho.HEALTHOBSERVATIONID = a.HEALTHOBSERVATIONID ) ) )final )alert_id_g )insert_alert ;";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			pstmt.setInt(2, patientId);
			pstmt.setInt(3, patientId);
			pstmt.setInt(4, patientId);
			pstmt.setInt(5, patientId);
			pstmt.setInt(6, patientId);
			pstmt.setInt(7, patientId);
			pstmt.setInt(8, patientId);
			int res = pstmt.executeUpdate();
			if (res == 0) {
				pstmt.close();
				rs.close();
				c1.close();
				con.close();
				return false;
			
				} else {
					System.out.println("Patient maintains said level of activity");
				}
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return true;
			} catch (Exception e) {
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			System.out.println("Error while generating inactivity alerts. Parent method. Error: " + e.getMessage());
			return false;
			}

	}
	
	// Generates inactivity alerts for a given patient id.
	public static boolean generateInactivityAlert(int patientId) throws SQLException {

		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		HashMap<Integer, ArrayList<Integer>> reco_map = new HashMap<Integer, ArrayList<Integer>>();
		HashMap<Integer, String> ho_name_map = new HashMap<Integer, String>();
		try {

			// get names of health observations
			String query = "select * from healthobservations";
			pstmt = c1.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ho_name_map.put(rs.getInt(1), rs.getString(2));
			}
			System.out.println(ho_name_map);

			// check if patient is well/sick
			query = "select patienttype from patients where patientid=?";
			pstmt = c1.prepareStatement(query);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			String isWell = (rs.next()) ? rs.getString(1) : "Well";

			if (isWell.equals(rs.getString(1))) {
				System.out.println("patient is well");
				query = "select * from ( select a.*, ROW_NUMBER() OVER (PARTITION BY a.HEALTHOBSERVATIONID ORDER BY a.frequency) AS freq from (select * from healthrecommendations where patientid=? and diagnosisid=0)a )b "
						+ " where b.freq= 1 union"
						+ " select healthrecommendations.*, 0 as freq from healthrecommendations where patientid is null and diagnosisid=0"
						+ " and HEALTHOBSERVATIONID not in (select HEALTHOBSERVATIONID from healthrecommendations where patientid=? and diagnosisid=0)";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, patientId);
			} else {
				System.out.println("patient is sick");
				query = " select * from ( select a.*, ROW_NUMBER() OVER (PARTITION BY a.HEALTHOBSERVATIONID ORDER BY a.frequency) AS freq from"
						+ "( select * from healthrecommendations where patientid=? and diagnosisid in (select diagnosisid from patientdiagnosis where "
						+ " patientid=? and isactive='Y') )a )b" + " where b.freq= 1 union"
						+ " select healthrecommendations.*, 0 as freq from healthrecommendations where patientid is null and diagnosisid in (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y')"
						+ " and HEALTHOBSERVATIONID not in (select HEALTHOBSERVATIONID from healthrecommendations where patientid=? and diagnosisid in "
						+ " (select diagnosisid from patientdiagnosis where patientid=? and isactive='Y') ) 	";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, patientId);
				pstmt.setInt(3, patientId);
				pstmt.setInt(4, patientId);
				pstmt.setInt(5, patientId);
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				int ho_id = rs.getInt(2);
				System.out.println(ho_id);
				System.out.println("Freq : " + rs.getInt(8) + " Threshold " + rs.getInt(9));
				if (reco_map.containsKey(ho_id)) {
					ArrayList<Integer> list = reco_map.get(ho_id);
					int freq = rs.getInt(8);
					System.out.println(freq);
					if (freq < list.get(0)) {
						list = new ArrayList<Integer>();
						list.add(freq);
						list.add(rs.getInt(9));
						reco_map.put(ho_id, list);
					}
				} else {
					ArrayList<Integer> list = new ArrayList<Integer>();
					list.add(rs.getInt(8));
					list.add(rs.getInt(9));
					reco_map.put(ho_id, list);
				}
			}
			System.out.println(reco_map);

			for (int healthobservationid : reco_map.keySet()) {
				System.out.println("Generating Alerts for Healthobservation id: " + healthobservationid);
				ArrayList<Integer> list = reco_map.get(healthobservationid);
				int freq = list.get(0);
				int threshold = list.get(1);
				int n = freq + (threshold * freq / 100);
				// calculate how recent you want the readings
				// get timestamp n days before
				Date d = new Date();
				Date dateBefore = new Date(d.getTime() - n * 24 * 3600 * 1000l);
				long before_timestamp = dateBefore.getTime();
				// check if atleast one reading is present in this time frame
				query = "select * from readings where patientid=? and healthobservationid=? and observationtime > ?";
				pstmt = c1.prepareStatement(query);
				pstmt.setInt(1, patientId);
				pstmt.setInt(2, healthobservationid);
				pstmt.setTimestamp(3, new java.sql.Timestamp(before_timestamp));
				rs = pstmt.executeQuery();
				boolean result = rs.next();

				if (result == false) {

					// get latest reading id
					query = "select max(readingid) from readings where patientid=? and healthobservationid=?";
					pstmt = c1.prepareStatement(query);
					pstmt.setInt(1, patientId);
					pstmt.setInt(2, healthobservationid);
					int readingid = 0;
					rs = pstmt.executeQuery();
					if (rs.next())
						readingid = rs.getInt(1);
					System.out.println("Latest reading id: " + readingid);
					// check if this reading id also exists in alerts
					query = "select readingid from alerts where readingid=? and alerttypeid=?";
					pstmt = c1.prepareStatement(query);
					pstmt.setInt(1, readingid);
					pstmt.setInt(2, 2);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						System.out.println("Alert already generated for this reading");
					} else {

						// insert inactivity threshold
						System.out.println("Insert inactivity alert for healthobservationid: " + healthobservationid);
						query = "insert into alerts (ALERTID,ALERTTYPEID,TIMESTAMP,READINGID,PATIENTID,DESCRIPTION) values ((select NVL(max(alertid), 0)+1 from alerts),2,current_timestamp,(select NVL(max(readingid),0) from readings where patientid=?),?,?)";
						pstmt = c1.prepareStatement(query);
						pstmt.setInt(1, patientId);
						pstmt.setInt(2, patientId);
						pstmt.setString(3,
								"Inactivity to record observations for " + ho_name_map.get(healthobservationid));
						int res = pstmt.executeUpdate();
						if (res == 0) {
							pstmt.close();
							rs.close();
							c1.close();
							con.close();
							System.out.println("No alert generated for healthobservationid " + healthobservationid);
							return false;
						}
					}

				} else {
					System.out.println("Patient maintains said level of activity");
				}
			}
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			return true;
		} catch (Exception e) {
			pstmt.close();
			rs.close();
			c1.close();
			con.close();
			System.out.println("Error while generating inactivity alerts. Parent method. Error: " + e.getMessage());
			return false;
		}
	}

	public static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}
	
	public static Object[][] getReadings(int patientId) throws SQLException {
		HashMap<Integer, HashMap<String, String>> health_obs = new HashMap<>();
		Object[][] s = null;
		ConnectionToOracle con = new ConnectionToOracle();
		Connection c1 = con.returnConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String query = "select count(*) from READINGS r inner join HEALTHOBSERVATIONs h on r.HEALTHOBSERVATIONID=h.HEALTHOBSERVATIONID where PATIENTID=?";
			pstmt = c1.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			rs.next();
			int count = 0;
			count = rs.getInt(1);
			
			String queryq = "select r.*, h.HEALTHOBSERVATIONNAME, h.METRIC from READINGS r inner join HEALTHOBSERVATIONs h on r.HEALTHOBSERVATIONID=h.HEALTHOBSERVATIONID where PATIENTID=?";
			pstmt = c1.prepareStatement(queryq, ResultSet.TYPE_SCROLL_INSENSITIVE);
			pstmt.setInt(1, patientId);
			rs = pstmt.executeQuery();
			s = new Object[count][5];
			count = 0;
			while (rs.next()) {
				Object[] row = new Object[5];				
				row[0] = rs.getTimestamp("UPLOADTIME");
				row[1] = rs.getInt("READINGVALUE");
				row[2] = rs.getTimestamp("OBSERVATIONTIME");
				row[3] = rs.getString("HEALTHOBSERVATIONNAME");
				row[4] = rs.getString("METRIC");
				
				s[count] = row;
				count = count + 1;
				
			}
			rs.close();
			pstmt.close();
			c1.close();
			con.close();
		} catch (Exception E) {
			rs.close();
			pstmt.close();
			c1.close();
			con.close();			
			System.out.println("error while fetching readings, error: " + E.getMessage());
		}
		return s;
	}

}
