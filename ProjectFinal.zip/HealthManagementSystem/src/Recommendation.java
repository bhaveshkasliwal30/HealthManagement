import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import oracle.net.aso.d;

import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Recommendation {

	JFrame frame;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Recommendation window = new Recommendation(6);
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public Recommendation(int pid) throws SQLException {
		initialize(pid);
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 */
	private void initialize(int pid) throws SQLException {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);

		JPanel panel = new JPanel();
		
		JComboBox comboBox = new JComboBox();
		
		HashMap<Integer, HashMap<String, Boolean>> map = new HashMap<Integer, HashMap<String, Boolean>>();
		try {
			map = DBHandling.getUserDiseases(pid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HashMap<String, Integer> disease_id_map = new HashMap<String, Integer>();
		
		for(int diagnosisId : map.keySet()){
			HashMap<String, Boolean> inner_map = map.get(diagnosisId);
			for(String disease : inner_map.keySet()){
				boolean val = inner_map.get(disease);
				
				if(val)
				{
					comboBox.addItem(disease);
					disease_id_map.put(disease, diagnosisId);
				}
			}
		}
		
		Integer selectedDisease = disease_id_map.get(comboBox.getSelectedItem());
		
		JLabel lblDiagnosis = new JLabel("Diagnosis: ");
		lblDiagnosis.setForeground(Color.RED);
		
		JLabel lblObservation = new JLabel("Observation: ");
		lblObservation.setForeground(Color.RED);
		
		JComboBox comboBox_1 = new JComboBox();
		ArrayList<HealthObservationBO> nonOrdinal = new ArrayList<HealthObservationBO>();
		nonOrdinal = HealthObservationBO.getNonOrdinalHealthRecommendations();
		HashMap<String, Integer> ho_id_map = new HashMap<String, Integer>();
		
		for (HealthObservationBO no : nonOrdinal){
			ho_id_map.put(no.healthObservationName, no.healthObservationId);
			comboBox_1.addItem(no.healthObservationName);
		}
		
		Integer selectedHO = ho_id_map.get(comboBox_1.getSelectedItem());
		
		JLabel lblUpperLimit = new JLabel("Upper Limit:");
		lblUpperLimit.setForeground(Color.RED);
		
		JLabel lblLowerLimit = new JLabel("Lower Limit: ");
		lblLowerLimit.setForeground(Color.RED);
		
		JLabel lblFrequency = new JLabel("Frequency:");
		lblFrequency.setForeground(Color.RED);
		
		JComboBox comboBox_2 = new JComboBox();
		for(int i=0; i<350; i++){
			comboBox_2.addItem(i);
       }
		
		JComboBox comboBox_3 = new JComboBox();
		for(int i=0; i<350; i++){
			comboBox_3.addItem(i);
       }
		JComboBox comboBox_4 = new JComboBox();
		for(int i=0; i<50; i++){
			comboBox_4.addItem(i);
       }
		JButton btnUpdateNumericRecommendation = new JButton("Update Numeric Recommendation");
		
		
		JLabel lblUpdateOrdinalData = new JLabel("Update Ordinal Data:");
		lblUpdateOrdinalData.setForeground(Color.GREEN);
		
		JLabel lblOrdinal = new JLabel("Ordinal Observation:");
		lblOrdinal.setForeground(Color.RED);
		
		JLabel lblOrdinalValue = new JLabel("Upper Limit:");
		lblOrdinalValue.setForeground(Color.RED);
		
		
		
		

		JComboBox comboBox_5 = new JComboBox();
		
		
		ArrayList<HealthObservationBO> ordinal = new ArrayList<HealthObservationBO>();
		ordinal = HealthObservationBO.getOrdinalHealthRecommendations();
		HashMap<String, Integer> ordinal_id_map = new HashMap<String, Integer>();
		HashMap<Integer, HashMap<String, Integer> > ordinal_id_ordinal_value_map = new HashMap<Integer, HashMap<String, Integer> >();
		
		for (HealthObservationBO o : ordinal){
			ordinal_id_map.put(o.healthObservationName,o.healthObservationId);
//			comboBox_5.addItem(o.healthObservationName);
			ordinal_id_ordinal_value_map.put(o.healthObservationId, new HashMap<String, Integer>());
			
		}
		for(String key : ordinal_id_map.keySet()){
			comboBox_5.addItem(key);
		}
		
		
		for (HealthObservationBO o : ordinal){
			ordinal_id_ordinal_value_map.get(o.healthObservationId).put(o.ordinalName, o.ordinalValue);
		}
		comboBox_5.setSelectedIndex(0);
		
		
		
		JComboBox comboBox_6 = new JComboBox();
		String a = comboBox_5.getSelectedItem().toString();
		Integer c = ordinal_id_map.get(a);
		HashMap<String, Integer> b = ordinal_id_ordinal_value_map.get(c);
		for(String ordinal_name : b.keySet()){
			comboBox_6.addItem(ordinal_name);
		}
		
		comboBox_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox_6.removeAllItems();
				String a = comboBox_5.getSelectedItem().toString();
				Integer c = ordinal_id_map.get(a);
				HashMap<String, Integer> b = ordinal_id_ordinal_value_map.get(c);
				for(String ordinal_name : b.keySet()){
					comboBox_6.addItem(ordinal_name);
				}
			}
		});
		
		
		
		Integer selectedOrdinalId = ordinal_id_map.get(comboBox_5.getSelectedItem());
		Integer selectedULOrdinalValue = ordinal_id_ordinal_value_map.get(ordinal_id_map.get(comboBox_5.getSelectedItem().toString())).get(comboBox_6.getSelectedItem());
		
		
		JLabel label = new JLabel("Diagnosis: ");
		label.setForeground(Color.RED);
		
		JComboBox comboBox_7 = new JComboBox();
		
		HashMap<Integer, HashMap<String, Boolean>> map2 = new HashMap<Integer, HashMap<String, Boolean>>();
		try {
			map2 = DBHandling.getUserDiseases(pid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HashMap<String, Integer> disease_id_map2 = new HashMap<String, Integer>();
		
		for(int diagnosisId : map2.keySet()){
			HashMap<String, Boolean> inner_map = map2.get(diagnosisId);
			for(String disease : inner_map.keySet()){
				boolean val = inner_map.get(disease);
				
				if(val)
				{
					comboBox_7.addItem(disease);
					disease_id_map2.put(disease, diagnosisId);
				}
			}
		}
		Integer selectedLLOrdinalValue = ordinal_id_ordinal_value_map.get(ordinal_id_map.get(comboBox_5.getSelectedItem().toString())).get(comboBox_7.getSelectedItem());
		
		Integer selectedDisease2 = disease_id_map2.get(comboBox_7.getSelectedItem());
		
		JLabel lblLowerLimit_1 = new JLabel("Lower Limit:");
		lblLowerLimit_1.setForeground(Color.RED);
		
		JComboBox comboBox_8 = new JComboBox();
		String a2 = comboBox_5.getSelectedItem().toString();
		Integer c2 = ordinal_id_map.get(a2);
		HashMap<String, Integer> b2 = ordinal_id_ordinal_value_map.get(c2);
		for(String ordinal_name : b2.keySet()){
			comboBox_8.addItem(ordinal_name);
		}
		Integer selectedHO2 = ordinal_id_map.get(comboBox_5.getSelectedItem());
		
		comboBox_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox_8.removeAllItems();
				String a = comboBox_5.getSelectedItem().toString();
				Integer c = ordinal_id_map.get(a);
				HashMap<String, Integer> b = ordinal_id_ordinal_value_map.get(c);
				for(String ordinal_name : b.keySet()){
					comboBox_8.addItem(ordinal_name);
				}
			}
		});
		
		
		JLabel label_1 = new JLabel("Frequency:");
		label_1.setForeground(Color.RED);
		
		JComboBox comboBox_9 = new JComboBox();
		for(int i=0; i<50; i++){
			comboBox_9.addItem(i);
		}
		JButton btnUpdateOrdinalRecommendation = new JButton("Update Ordinal Recommendation");
		
		
		JLabel lblAlertThreshold = new JLabel("Alert Threshold (%):");
		lblAlertThreshold.setForeground(Color.RED);
		
		JLabel lblInactivityThreshold = new JLabel("Inactivity Threshold (%):");
		lblInactivityThreshold.setForeground(Color.RED);
		
		JComboBox comboBox_10 = new JComboBox();
		for(int i=0; i<100; i++){
			comboBox_10.addItem(i);
		}
		
		JComboBox comboBox_11 = new JComboBox();
		for(int i=0; i<100; i++){
			comboBox_11.addItem(i);
		}
		
		JLabel lblConsecutiveReadingsFor = new JLabel("Consecutive Readings for Alert:");
		lblConsecutiveReadingsFor.setForeground(Color.RED);
		
		JComboBox comboBox_12 = new JComboBox();
		for(int i=0; i<100; i++){
			comboBox_12.addItem(i);
		}
		btnUpdateNumericRecommendation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String res = HealthSupporterBO.InsertUpdateRecommendation(0, selectedHO, selectedDisease, pid, Integer.parseInt(comboBox_11.getSelectedItem().toString()), Integer.parseInt(comboBox_2.getSelectedItem().toString()), Integer.parseInt(comboBox_3.getSelectedItem().toString()), Integer.parseInt(comboBox_4.getSelectedItem().toString()), Integer.parseInt(comboBox_10.getSelectedItem().toString()), Integer.parseInt(comboBox_12.getSelectedItem().toString()));
				JOptionPane.showMessageDialog(frame ,res);
			}
		});
		JLabel label_2 = new JLabel("Inactivity Threshold (%):");
		label_2.setForeground(Color.RED);
		
		JLabel label_3 = new JLabel("Alert Threshold (%):");
		label_3.setForeground(Color.RED);
		
		JLabel label_4 = new JLabel("Consecutive Readings for Alert:");
		label_4.setForeground(Color.RED);
		
		JComboBox comboBox_13 = new JComboBox();
		for(int i=0; i<100; i++){
			comboBox_13.addItem(i);
		}
		
		JComboBox comboBox_14 = new JComboBox();
		for(int i=0; i<100; i++){
			comboBox_14.addItem(i);
		}
		
		JComboBox comboBox_15 = new JComboBox();
		for(int i=0; i<100; i++){
			comboBox_15.addItem(i);
		}
		
		btnUpdateOrdinalRecommendation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String res = HealthSupporterBO.InsertUpdateRecommendation(0, selectedOrdinalId, selectedDisease2, pid, Integer.parseInt(comboBox_14.getSelectedItem().toString()), selectedULOrdinalValue, selectedLLOrdinalValue, Integer.parseInt(comboBox_9.getSelectedItem().toString()), Integer.parseInt(comboBox_13.getSelectedItem().toString()), Integer.parseInt(comboBox_15.getSelectedItem().toString()));
				JOptionPane.showMessageDialog(frame ,res);
			}
		});
		
//		JTableHeader header = table.getTableHeader();
//		JPanel panel = new JPanel();
//		panel.setLayout(new BorderLayout());
//		panel.add(header, BorderLayout.NORTH);
//		panel.add(table, BorderLayout.CENTER);
		
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(183)
					.addComponent(btnUpdateOrdinalRecommendation, GroupLayout.PREFERRED_SIZE, 258, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(709, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(56)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 122, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
								.addContainerGap())
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblUpdateOrdinalData)
									.addPreferredGap(ComponentPlacement.RELATED, 305, Short.MAX_VALUE)
									.addComponent(btnUpdateNumericRecommendation)
									.addGap(400))
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addGroup(groupLayout.createSequentialGroup()
											.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
												.addGroup(groupLayout.createSequentialGroup()
													.addComponent(lblDiagnosis)
													.addGap(19))
												.addComponent(lblOrdinalValue)
												.addComponent(label, GroupLayout.PREFERRED_SIZE, 71, GroupLayout.PREFERRED_SIZE)
												.addComponent(lblOrdinal)
												.addComponent(lblLowerLimit_1, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
												.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
												.addComponent(lblFrequency)
												.addComponent(lblLowerLimit)
												.addGroup(groupLayout.createSequentialGroup()
													.addGap(156)
													.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
														.addComponent(comboBox_14, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
														.addComponent(comboBox_13, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)))
												.addComponent(lblObservation)
												.addComponent(lblUpperLimit))
											.addGap(111)
											.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
												.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
													.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
														.addComponent(comboBox_2, Alignment.TRAILING, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(comboBox_3, Alignment.TRAILING, 0, 255, Short.MAX_VALUE))
													.addGroup(groupLayout.createSequentialGroup()
														.addPreferredGap(ComponentPlacement.RELATED)
														.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
															.addComponent(comboBox_8, GroupLayout.PREFERRED_SIZE, 254, GroupLayout.PREFERRED_SIZE)
															.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
																.addComponent(comboBox_5, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
																.addComponent(comboBox_7, GroupLayout.PREFERRED_SIZE, 272, GroupLayout.PREFERRED_SIZE))
															.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
																.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 198, GroupLayout.PREFERRED_SIZE)
																.addComponent(comboBox_9, GroupLayout.PREFERRED_SIZE, 266, GroupLayout.PREFERRED_SIZE))))
													.addGroup(groupLayout.createSequentialGroup()
														.addGap(24)
														.addComponent(comboBox_6, 0, 248, Short.MAX_VALUE))
													.addComponent(comboBox_4, 0, 272, Short.MAX_VALUE))
												.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
													.addComponent(comboBox_1, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(comboBox, 0, 263, Short.MAX_VALUE)))
											.addPreferredGap(ComponentPlacement.RELATED)
											.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
												.addGroup(groupLayout.createSequentialGroup()
													.addComponent(lblInactivityThreshold)
													.addPreferredGap(ComponentPlacement.RELATED)
													.addComponent(comboBox_10, 0, 148, Short.MAX_VALUE))
												.addComponent(comboBox_15, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)))
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(lblAlertThreshold)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addComponent(comboBox_11, 0, 179, Short.MAX_VALUE)
											.addGap(51)
											.addComponent(lblConsecutiveReadingsFor)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(comboBox_12, 0, 179, Short.MAX_VALUE)
											.addGap(281))
										.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 1028, Short.MAX_VALUE))
									.addGap(66))))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(17)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDiagnosis)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblObservation))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblUpperLimit))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblLowerLimit))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblFrequency)
						.addComponent(lblInactivityThreshold)
						.addComponent(comboBox_10, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblAlertThreshold)
								.addComponent(comboBox_11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblConsecutiveReadingsFor)
								.addComponent(comboBox_12, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(27)
							.addComponent(lblUpdateOrdinalData)
							.addGap(6))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnUpdateNumericRecommendation)
							.addGap(21)))
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(comboBox_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblOrdinal)
						.addComponent(comboBox_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(17)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblOrdinalValue)
						.addComponent(comboBox_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLowerLimit_1)
						.addComponent(comboBox_8, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(comboBox_9, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_2)
								.addComponent(comboBox_13, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_3)
								.addComponent(comboBox_14, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(18)
							.addComponent(btnUpdateOrdinalRecommendation))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(16)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_4)
								.addComponent(comboBox_15, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 214, GroupLayout.PREFERRED_SIZE)
					.addGap(20))
		);
		

		HashMap<Integer, HashMap<String, String>> hr = DBHandling.getHealthIndicators(pid);

		String[] columnNames = {"HealthObservationName", "Metric", "Threshold", "UpperLimit", "LowerLimit", "Frequency"};
        
        Object[][] data = new Object[hr.size()][5];
        Integer count = 0;
		for(int hrId : hr.keySet()){
			HashMap<String, String> inner_map = hr.get(hrId);
			Object[] temp_data = {
					inner_map.get("HealthObservationName"),
					inner_map.get("metric"),
					inner_map.get("Threshold"),
					inner_map.get("UpperLimit"),
					inner_map.get("LowerLimit"),
					inner_map.get("Frequency")		
			};
			
			data[count] = temp_data;
			count = count + 1;
			
		}

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable( model );
        table.setColumnSelectionAllowed(true);
        table.setCellSelectionEnabled(true);
//		table = new JTable(rowData, columnNamesV);
//		JTableHeader tableHeader=new JTableHeader(cm);
//		table.setTableHeader(tableHeader);
		table.setBackground(Color.WHITE);
		table.setForeground(Color.RED);
		JTableHeader header = table.getTableHeader();
//		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(header, BorderLayout.NORTH);
		panel.add(table, BorderLayout.CENTER);
		panel.add(table);
		frame.getContentPane().setLayout(groupLayout);
		frame.setBounds(30, 30, 1150, 820);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
